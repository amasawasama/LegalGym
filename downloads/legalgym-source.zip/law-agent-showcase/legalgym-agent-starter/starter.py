"""Run a user-owned agent in a separate process; wait for website-started jobs."""
import argparse
import importlib
import json
import os
from pathlib import Path
import re
import threading
import time
from client import Client, Environment


def save_replay_package(client, run_id, directory):
    packet = client.request(f"/api/runs/{run_id}/replay-package")
    if packet.get("schema") != "legalgym.replay.v1":
        raise RuntimeError("Unsupported replay package")
    directory = Path(directory)
    directory.mkdir(parents=True, exist_ok=True)
    filename = re.sub(r"[^A-Za-z0-9_.-]", "_", run_id) + ".legalgym.json"
    output = directory / filename
    output.write_text(json.dumps(packet, ensure_ascii=False), encoding="utf-8")
    return output


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--server", default="http://127.0.0.1:8841")
    parser.add_argument("--name", default="外部 Agent 示例")
    parser.add_argument("--agent-entry", default="demo_agent:run", help="Python module:function")
    parser.add_argument("--version", default="starter-demo-0.2.0")
    parser.add_argument("--replay-dir", type=Path, default=Path(__file__).resolve().parent / "runs")
    args = parser.parse_args()
    model = os.environ.get("LEGALGYM_MODEL", "zai-org/glm-5.3-flash")
    key = os.environ.get(os.environ.get("LEGALGYM_KEY_ENV", "OPENAI_API_KEY"), "")
    module, name = args.agent_entry.split(":", 1)
    implementation = getattr(importlib.import_module(module), name)
    client = Client(args.server)
    registration = client.request("/api/agents/register", {
        "name": args.name, "model": model, "version": args.version})
    client.token = registration["token"]
    agent_id = registration["id"]
    print(f"已连接 LegalGym：{args.name}（{model}）", flush=True)
    print("等待网页点击“开始运行”。模型密钥保留在本进程，不上传至任务后端。", flush=True)
    done = threading.Event()

    def heartbeat():
        while not done.wait(5):
            try:
                client.request(f"/api/agents/{agent_id}/heartbeat", {})
            except Exception:
                pass

    threading.Thread(target=heartbeat, daemon=True).start()
    try:
        while True:
            job = client.request(f"/api/agents/{agent_id}/job")
            if not job or not job.get("runId"):
                continue
            run_id = job["runId"]
            print("领取任务：" + run_id, flush=True)

            def report(message, usage=None):
                safe = str(message).replace(key, "[REDACTED]") if key else str(message)
                client.request(f"/api/runs/{run_id}/agent-events", {"message": safe, "usage": usage})
                print(safe[:500], flush=True)

            try:
                environment = Environment(client, job)
                result = implementation(job["task"], environment, report)
                status, message = "completed", str(result or "Agent 已结束。")
            except Exception as error:
                status, message = "failed", str(error)
                if key:
                    message = message.replace(key, "[REDACTED]")
            result = client.request(f"/api/runs/{run_id}/finish", {"status": status, "message": message}, timeout=180)
            try:
                output = save_replay_package(client, run_id, args.replay_dir)
                print(f"回放包已保存：{output}\n可在静态网页中直接导入，不必上传云端。", flush=True)
            except Exception:
                print("自动下载回放包未成功，仍可在网页中点击“下载回放包”。", flush=True)
            print(f"任务结束：{result['status']}；继续等待下一次网页运行。", flush=True)
    except KeyboardInterrupt:
        print("Starter 已断开。", flush=True)
    finally:
        done.set()


if __name__ == "__main__":
    main()
