"""Example agent: independent OpenAI-compatible tool loop, with no dsh dependency."""
import json
import os
import ssl
import time
import urllib.request
import urllib.error
from pathlib import Path


def run(task, environment, report):
    key_name = os.environ.get("LEGALGYM_KEY_ENV", "OPENAI_API_KEY")
    key = os.environ.get(key_name)
    if not key:
        raise RuntimeError(f"请先在本机设置 {key_name}；不要在网页或日志中填写密钥。")
    base = os.environ.get("LEGALGYM_MODEL_BASE_URL", "https://api-cdn.deploy.com/api/v1").rstrip("/")
    model = os.environ.get("LEGALGYM_MODEL", "zai-org/glm-5.3-flash")
    context = ssl.create_default_context()
    if Path("/etc/ssl/cert.pem").is_file():
        context.load_verify_locations("/etc/ssl/cert.pem")
    definitions = environment.list_tools()
    tools = [{"type": "function", "function": {
        "name": tool["name"], "description": tool["description"], "parameters": tool["inputSchema"]}}
        for tool in definitions]
    requires_submission = any(tool["name"] == "submit" for tool in definitions)
    submitted = False
    messages = [{"role": "system", "content":
        "你是通过 LegalGym 接口执行任务的独立 agent。阅读任务，使用可用工具自主完成。"
        "遵守工具参数格式；工具报错时根据返回信息纠正。提交真实查证后的交付物，成功后简短报告完成。"
        "不要声称已执行未调用的操作。"}, {"role": "user", "content": task}]
    for step in range(1, 17):
        environment.check_running()
        report(f"模型请求第 {step} 步，等待响应。")
        payload = {"model": model, "messages": messages, "tools": tools,
                   "tool_choice": os.environ.get("LEGALGYM_TOOL_CHOICE", "required"),
                   "stream": False, "max_tokens": 8192,
                   "thinking": {"type": "disabled"}}
        body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        request = urllib.request.Request(base + "/chat/completions", data=body,
            headers={"Content-Type": "application/json", "Authorization": "Bearer " + key})
        for attempt in range(2):
            try:
                with urllib.request.urlopen(request, context=context, timeout=150) as response:
                    data = json.load(response)
                break
            except urllib.error.HTTPError as error:
                if error.code in {429, 500, 502, 503, 504} and attempt == 0:
                    report(f"模型接口 HTTP {error.code}，稍后重试。")
                    time.sleep(2)
                    continue
                raise RuntimeError(f"模型接口 HTTP {error.code}，请检查本机模型配置。") from None
            except urllib.error.URLError as error:
                raise RuntimeError("模型连接失败：" + str(error.reason).replace(key, "[REDACTED]")) from None
        message = data["choices"][0]["message"]
        entry = {"role": "assistant", "content": message.get("content")}
        if message.get("reasoning_content") is not None:
            entry["reasoning_content"] = message["reasoning_content"]
        calls = message.get("tool_calls", [])
        if calls:
            entry["tool_calls"] = calls
        messages.append(entry)
        if entry["content"]:
            report(entry["content"], usage=data.get("usage"))
        elif data.get("usage"):
            report(f"第 {step} 步模型响应已返回。", usage=data["usage"])
        if not calls:
            if requires_submission and not submitted:
                report("尚未收到真实 submit 调用，将请模型纠正调用格式。")
                messages.append({"role": "user", "content":
                    "你还没有通过接口调用 submit。普通文本中的工具名称或 <tool_call> 标记不会执行。"
                    "请使用本次请求提供的 function tools，发出结构化工具调用以提交完整交付物，内容保持简明。"})
                continue
            return entry["content"] or "Agent 已结束。"
        for call in calls:
            function = call["function"]
            try:
                arguments = json.loads(function["arguments"])
            except ValueError:
                result = {"isError": True, "content": [{"type": "text", "text": "工具参数必须为有效 JSON。"}]}
            else:
                result = environment.call_tool(function["name"], arguments)
                if function["name"] == "submit" and not result.get("isError"):
                    submitted = True
            text = "\n".join(part.get("text", "") for part in result.get("content", []))
            if result.get("isError"):
                text = "工具执行错误：" + text
            messages.append({"role": "tool", "tool_call_id": call["id"], "content": text})
        if submitted:
            return "Agent 已通过 submit 工具提交交付物，等待平台检查与律师复核。"
    raise RuntimeError("达到示例 agent 的 16 步模型调用上限。")
