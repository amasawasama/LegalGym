"""Small stdlib client for the local hub and its MCP HTTP tool endpoint."""
import json
import urllib.request
import urllib.error
from urllib.parse import urlparse


class Client:
    def __init__(self, server, token=None):
        parsed = urlparse(server)
        if parsed.scheme != "http" or parsed.hostname not in {"127.0.0.1", "localhost"}:
            raise ValueError("This starter prototype only connects to a local HTTP hub.")
        self.server = server.rstrip("/")
        self.token = token

    def request(self, path, data=None, timeout=35):
        headers = {"Accept": "application/json, text/event-stream"}
        if self.token:
            headers["Authorization"] = "Bearer " + self.token
        body = None
        if data is not None:
            body = json.dumps(data, ensure_ascii=False).encode("utf-8")
            headers["Content-Type"] = "application/json"
        request = urllib.request.Request(self.server + path, data=body, headers=headers)
        try:
            with urllib.request.urlopen(request, timeout=timeout) as response:
                result = response.read()
                return json.loads(result) if result else None
        except urllib.error.HTTPError as error:
            try:
                message = json.loads(error.read()).get("error", "HTTP error")
            except ValueError:
                message = "HTTP error"
            raise RuntimeError(f"Hub HTTP {error.code}: {message}") from None


class Environment:
    def __init__(self, client, job):
        self.client, self.job = client, job
        self.sequence = 0
        self.request("initialize", {"protocolVersion": "2025-11-25", "capabilities": {},
                     "clientInfo": {"name": "legalgym-agent-starter", "version": "0.1.0"}})
        self.client.request(job["mcpUrl"], {"jsonrpc": "2.0", "method": "notifications/initialized"})

    def request(self, method, params=None):
        self.sequence += 1
        result = self.client.request(self.job["mcpUrl"], {
            "jsonrpc": "2.0", "id": self.sequence, "method": method, "params": params or {}})
        if "error" in result:
            raise RuntimeError(str(result["error"]))
        return result["result"]

    def list_tools(self):
        return self.request("tools/list")["tools"]

    def call_tool(self, name, arguments):
        self.check_running()
        return self.request("tools/call", {"name": name, "arguments": arguments})

    def check_running(self):
        state = self.client.request("/api/runs/" + self.job["runId"])
        if state["status"] != "running":
            raise RuntimeError("Run stopped or no longer active")
