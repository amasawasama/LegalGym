# LegalGym Agent Starter · Agent 接入范例

本范例的目的：引导参与者把自己已有的 agent 接到 LegalGym 的网页任务、环境工具和交付记录上。示例模型只是用于体验这条连接链路，可以整体替换。

这个目录可以单独复制作为客户端使用，但运行任务仍需要完整 LegalGym 项目的本机后端。GitHub Pages 只提供静态展示与回放，不会执行 Python。Starter 是独立 Python 进程，不依赖 dsh。
示例 `demo_agent.py` 使用 OpenAI-compatible 模型接口，自主决定工具调用。
模型密钥保留在 starter 进程；LegalGym 后端提供任务、MCP 工具、事件记录和 replay。

## 运行

1. 在 LegalGym 仓库根目录启动后端：`.venv/bin/python local_lab/server.py`。
2. 在另一个终端配置 `OPENAI_API_KEY`（不要提交到 Git），按需设置 `.env.example` 中的其他环境变量。
3. 执行 `python3 legalgym-agent-starter/starter.py --server http://127.0.0.1:8841`。
4. 打开 `http://127.0.0.1:8841/lab/`，选择在线 agent，点击“开始运行”。

后端需要已有的 Playwright、可用 Chromium 和 python-docx 1.2+；Starter 自身只使用 Python 标准库。
示例默认使用 Deploy 的 GLM-5.3-Flash；其他 OpenAI-compatible 服务需要设置对应 Base URL、模型及密钥。
示例默认 `tool_choice=required`；不支持此选项的模型服务可设置 `LEGALGYM_TOOL_CHOICE=auto`。示例会检查实际 submit 成功，不把正文中的伪工具调用当作交付。
`.env.example` 仅为配置说明，不自动加载。模型请求超时为 150 秒，最多 16 步模型调用。

## 两种使用方式

- **先体验完整流程**：使用默认 `demo_agent:run`。这是一个可运行的示例 agent，会调用你配置的模型接口，自主操作工具并提交；可能产生模型费用。
- **测试自己的 agent**：复制 `adapter_template.py`，实现其中的 `run_own_agent()`，通过 `--agent-entry adapter_template:run` 加载。模板不会调用模型或提供预设答案；未实现时明确报错。

## 一次任务如何接进来

```text
网页点击“开始运行”
  → 后端创建独立案卷，starter 领取 task 和本次 MCP 地址
  → starter 调用 run(task, environment, report)
  → 适配层把 task 和工具定义交给你的 agent
  → 你的 agent 决定调用 → 适配层执行 environment.call_tool
  → 原样把工具结果交回 agent，继续执行
  → agent 按任务要求通过实际工具提交交付物
  → 函数返回结束说明，后端检查交付并导出记录
```

网页不直接向任意 agent 程序注入提示词。Starter 负责领取任务和调用入口；适配层负责把收到的任务与工具交给你的 agent。
当前后端从本次案卷的 `TASK.md` 下发任务。示例 agent 把它作为用户消息输入模型；你可以采用适合自己框架的等效输入方式。

## 需要统一的最小接入约定

提供一个同步 Python 函数：

```python
def run(task, environment, report):
    # 请查看 adapter_template.py；这里不包含解题逻辑。
    tools = environment.list_tools()
    # task: 本次任务全文，不要在 agent 代码里写死某个案例。
    # tools: [{name, description, inputSchema}, ...]，用于注册模型工具。
    # environment.call_tool(name, arguments): 执行真实操作，返回 MCP 结果。
    # environment.check_running(): 检查停止状态；请在自己的循环中调用。
    # report("进度说明"): 可选，向网页发送简短进度。
    # 由自己的 agent 执行；完成后返回说明，不等于提交交付物。
```

用以下命令加载实现后的模板（模块放在 starter 同目录，或通过 `PYTHONPATH` 提供）：

```bash
python3 legalgym-agent-starter/starter.py --server http://127.0.0.1:8841 --agent-entry adapter_template:run --name "My Legal Agent" --version "my-agent-0.1"
```

适配层应做到：

1. 将收到的 `task` 交给自己的 agent；不要复用首页示例的任务结果或预设调用顺序。
2. 动态读取工具名称、描述和 JSON Schema，转换成自己框架的工具格式。不要把“永远只有三个工具”写成通用假设。
3. 将结构化调用派发给 `environment.call_tool(name, arguments)`，保留并回传完整结果，包括 `content` 和 `isError`。错误也应反馈给 agent，供其修正。
4. 按本次任务及工具定义提交。当前 C06 使用 `submit`；普通文本中的工具名称、XML 标记或“已完成”不会执行操作。
5. 在执行循环中检查停止状态。完成后正常返回，失败时抛出异常；不要吞掉错误并伪装成功。框架为异步或独立进程时，在此同步入口内完成等待和结果转接。

`report` 的消息会在网页显示，但属于 agent 自报。工具调用、返回及浏览截图由环境记录；网页不会自动读取 agent 的全部内部步骤，也不要求提交隐藏推理过程。不要将模型密钥写入消息。

## 环境规定什么，agent 自己决定什么

环境规定本次委托、可用工具、工具参数、交付结构与完成条件。当前 C06 的查询、已打开证据引用和条款覆盖要求属于该案例，不是所有未来任务的固定规则。任务文字中的行为限制也不都等同于操作系统沙箱隔离。

参与者自行选择模型、框架、提示词、规划方法、记忆和协作方式。示例的 Deploy 默认配置、`tool_choice`、重试与 16 步上限仅属于 `demo_agent.py`，不作为其他 agent 的共同要求。模型密钥由参与者在自己进程中配置。
Starter 不预设查证顺序、风险结论、修订内容或最终答案，连接层可以复用。

非 Python agent 可以在此适配层内调用自己的进程或服务。也可以自行实现任务领取与运行级工具协议，替换整个 Python starter；当前版本尚未提供其他语言的现成适配器。支持 MCP 的客户端仍需处理 LegalGym 的任务领取、运行身份和结束报告；仅配置一个 MCP 地址并不自动完成整条接入流程。
当前 MCP HTTP 入口实现初始化、工具发现和工具调用，不提供通用公网 MCP 托管。

## 如何确认接入正确

- 在网页中看见自己的 agent 在线；点击开始后，程序收到了本次任务。
- 执行日志出现环境记录的 `tool_call` 和 `tool_result`，而不仅是 agent 声称“已查询”。
- 遇到错误时，agent 能收到工具错误并继续纠正；停止后不继续发出环境工具操作。
- 交付通过实际提交工具产生，并通过后端检查；函数返回“完成”不足以满足这一点。
- 在本次运行页查看回放、下载 Word、导出 `.legalgym.json`，然后在静态网页导入复核。

以上是接通与流程检查，不代表法律质量合格或获得正式 benchmark 分数。验证接口时可先用自己的模拟 agent；要验证模型自主表现，应运行真实 agent，不把模拟动作包装为模型结果。

## 记录和边界

- 每次运行独立保存在 `.run/lab/<run-id>/`。
- 每次结束自动写入 `portable-replay.legalgym.json`。网页也可通过“导出回放包”下载同样的记录。
- Starter 会自动把回放包下载到自己目录的 `runs/`；可用 `--replay-dir` 指定其他本地文件夹。
- 这个包包含事件、截图、全部 Word 页面和原 Word，不含模型密钥。把它导入静态 `site/lab/index.html`，无需运行后端就能在浏览器里回放；刷新后需要重新导入。
- `events.jsonl` 是后端记录的统一事件；工具事件标记为 `environment`，agent 自报消息标记为 `agent`。
- 运行完成后检查实际提交及证据记录，通过后导出独立 replay 和 Word；失败仍保留日志及截图。
- 当前没有法律质量评分、正式排行榜或公网账号系统。
- 仅绑定本机 loopback；使用本机 starter 配对令牌，不适合直接暴露到公网。
- “停止”会阻止后续工具操作，当前模型 HTTP 请求可能要返回或超时后才退出。
- 本机用户能控制自己的进程，记录适合开发验证，不等同于可防篡改的正式评测证据。
