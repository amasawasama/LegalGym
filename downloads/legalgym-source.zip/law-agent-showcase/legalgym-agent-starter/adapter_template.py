"""Replace run_own_agent() to connect an existing agent; this file is not a solver.

Start with:
    python3 legalgym-agent-starter/starter.py --agent-entry adapter_template:run

The starter receives the task when the website creates a run. Do not embed the
C06 task, tool names, model choice, or expected answers in this adapter.
"""


def run_own_agent(*, task, tools, call_tool, report, check_running):
    """Integration point for YOUR agent framework.

    task: task text from the environment; pass it into your agent's input.
    tools: list of {name, description, inputSchema}; register with your agent.
    call_tool(name, arguments): execute an actual environment tool and return
        the full MCP result, including content and isError. Feed that result
        back to your agent, including errors so it can correct its next action.
    report(message): optional concise progress message visible in the website.
    check_running(): raises if the run was stopped; call between agent steps.

    Replace this function with your framework's execution loop, passing tool
    invocations through call_tool. Return only when YOUR agent has ended.
    A returned string is a status message, NOT a submitted deliverable.
    """
    raise NotImplementedError(
        "这是接入模板：请先实现 adapter_template.py 的 run_own_agent，"
        "把任务、工具定义和调用回调交给自己的 agent；"
        "如需先体验可运行示例，请使用 --agent-entry demo_agent:run。"
    )


def run(task, environment, report):
    environment.check_running()
    tools = environment.list_tools()

    def call_tool(name, arguments):
        # Keep real calls inside this run's environment for logging and replay.
        environment.check_running()
        return environment.call_tool(name, arguments)

    report("适配器已收到本次任务和工具定义，准备交给自定义 agent。")
    return run_own_agent(
        task=task,
        tools=tools,
        call_tool=call_tool,
        report=report,
        check_running=environment.check_running,
    )
