# 发布网页与运行 Agent

## 应上传哪些文件

推荐保留完整源码目录：

```text
.github/workflows/pages.yml    GitHub Actions：只发布 site/ 里的静态文件
site/                         完整网页，含首页、资料室、实验室、示例和 starter ZIP
local_lab/                    本机后端、记录导出、文档预览与测试
legalgym-agent-starter/        独立 starter、示例 agent、客户端与空白配置模板
case/                         虚构任务、合同和三个工具
export_run.py                 交付 Word 和记录的导出器
run_case.py                   旧 dsh 运行入口，可选兼容
requirements-local.txt        本机 Python 依赖
README.md
LOCAL_WORKFLOW.md
GITHUB_PAGES.md
.gitignore
```

不要上传 `.local-runtime/`、`.venv/`、`.run/`、真实 `.env`、starter 的 `runs/`、密钥或个人记录。
页面自带的 `site/lab/examples/c06-external-starter.legalgym.json` 是经选择的虚构任务开发回放，包含输出、截图和模型名称，不是正式成绩。

本仓库已准备 `.github/workflows/pages.yml`。保持 `site/` 结构，在仓库 Settings → Pages → Source 选择 **GitHub Actions**；推送 main 或手动运行该工作流，发布目录就是 `site/`。

如果只上传静态网页，使用 `legalgym-pages.zip`：解压后把里面的 `index.html`、JS、CSS、`assets/`、`mock/`、`lab/` 等放在发布分支根目录（不要再套一层 site/），在 Pages 选择该分支的 `/ (root)`。这与上面的完整源码＋Actions 是两种发布方式，选择其中一种。

## GitHub Pages 上实际可以做什么

- 看首页固定示例，翻阅两页修订 Word，下载合同。
- 打开 `lab/`，载入已打包的示例，或导入自己的 `.legalgym.json`；在本页交互回放、看日志和全部 Word 页面。
- 下载 starter ZIP，查看本机连接方法。

GitHub Pages 不运行 Python，上传 server.py 或 starter.py 也不会产生运行接口。当前静态实验室的“开始运行”会禁用；“打开本机运行页”会跳到使用者电脑的 `http://127.0.0.1:8841/lab/`。当前代码没有从 GitHub Pages 直接向 localhost 跨域发起任务。

## 现在可用的真实运行方式

先下载完整源码，安装 Python 3.11+，在仓库根目录运行：

```bash
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements-local.txt
.venv/bin/python -m playwright install chromium
.venv/bin/python local_lab/server.py --port 8841
```

Windows 使用 `.venv\Scripts\python.exe`。另一个终端按 starter/README 配置自己的模型环境变量，然后：

```bash
python3 legalgym-agent-starter/starter.py --server http://127.0.0.1:8841
```

从静态站点点击“打开本机运行页”，在本机页面选择已连接 agent → 开始运行 → 看实时日志 → 结束后在本页回放并下载 Word。starter 会自动保存回放包，也可在网页点击“导出回放包”，再回 GitHub Pages 导入查看，无需把个人回放上传仓库。

新电脑能运行 agent 与导出 Word；要生成 Word 全部页面 PNG，还需配置文档渲染器及中文字体，参照 `local_lab/README.md`。当前配置读取本机 Codex 文档运行时，不包含在下载包中；未配置仍可下载 Word，界面会显示预览不可用。网站自带示例的预渲染页面不受影响。

## 如需直接留在公网网页实时运行

需要另行部署支持 HTTP API、MCP 工具、SSE 实时事件流、浏览器与文件存储的后端，将前端连接地址改为该服务并配套认证和权限。当前服务绑定 loopback、拒绝跨域，并非公网配置。再增加账号、任务隔离、配额及可信评分后才能做正式提交和总榜。公开运行不能通过额外上传几个静态文件来实现。

## 制作发布包

```bash
python3 local_lab/package_release.py
```

输出 `.run/distribution/legalgym-pages.zip`（静态发布目录）与 `legalgym-source.zip`（完整可共享源码）。脚本只收集指定目录和文件，排除本机运行目录、环境文件和缓存。打包本身不会推送 GitHub，也不会启动 agent。
