# LegalGym 宣传站

GitHub Pages 发布与文件清单见 [发布说明](GITHUB_PAGES.md)。

本机 Agent 接入、同页交互回放、全部 Word 页面和纯静态导入方式见 [本机连接与静态回放](LOCAL_WORKFLOW.md)。独立客户端见 [Agent Starter](legalgym-agent-starter/README.md)。

面向律师和合作伙伴的本地静态展示。C06 演示改编自工程咨询合同审查工作流，案卷、公司和业务记录全部为虚构数据。

- `site/index.html` 是宣传站入口，可直接在浏览器打开。部署时静态托管整个 `site` 目录。
- `site/mock/index.html` 是可查询的模拟资料室，包含企业名录、融资台账、报价和授权记录。
- `site/assets/c06-contract-redline.docx` 由模型提交的条款修订和批注导出。这个样例用于律师复核。
- 参与入口可生成并复制意向说明，供访客发给项目分享人。公开发布前可换成项目的正式联系入口。

## 本次 UI 副本

本目录是 `law-agent-showcase-ui-v2`，原项目保持不变。默认本机端口为 8841。

- 首页以法律 Agent 工作环境为主线，移除视频占位；“查看 Agent 运行过程”跳转到已有示例的日志页，不创建新任务。
- 实验室保留执行日志、运行记录、合同交付三个页签；截图与页面文字合并到运行记录下。
- 运行入口与结果入口使用与站点一致的森林绿和鼠尾草绿突出；结果可用时显示提示。
- 主图选型见 `site/visual-directions.html`，三个 SVG 概念图位于 `site/assets/`，均不是运行截图。
- 展示用回放保持原样，只有界面和说明调整。模型凭据和 Python 虚拟环境没有复制到本目录。

首次使用可从公开网站下载自动配置启动包（预览版）。启动脚本可准备 Python、浏览器与依赖；仍需用户运行脚本和提供模型密钥。实验室按“查看已有运行、运行示例 Agent、接入自己的 Agent”组织入口。纯静态站默认载入参考运行并显示执行日志，隐藏不可用的启动控件；本机运行页按所选路径显示在线 Agent 与启动操作。

启动后打开 `http://127.0.0.1:8841/`。静态发布入口会自动载入打包示例；本机有对应运行记录时优先打开本机记录，避免生成重复导入项。

## 重跑 C06

需要 Python、Playwright Chromium 和可运行的 `dsh`。先将 `DEEPSEEK_API_KEY` 设置在环境变量中，再执行：

```powershell
python run_case.py --run-dir .run/c06-retest
```

运行目录应尚未存在。如果安装的 dsh 不在标准 npm 路径，可加 `--dsh-entry <dsh 安装目录中的 lib/bin.js>`。运行提供本案读取、模拟浏览器、答卷提交三个专用工具，使用本地回环地址和临时 dsh 配置。浏览器动作会留下页面文字和真实截图。

使用安装了 python-docx 1.2 或以上的 Python 导出：

```powershell
python export_run.py .run/c06-retest
```

导出检查答卷确实经 dsh 提交，并要求引用的记录在浏览器轨迹中可查；它不作法律质量评分。`.run/` 保存本地原始记录，宣传站在案例区域回放导出的操作轨迹，并提供修改后的 Word 合同下载。

