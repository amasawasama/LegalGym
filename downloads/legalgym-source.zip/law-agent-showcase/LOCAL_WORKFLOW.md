# LegalGym 本机连接与静态回放

本目录同时包含网页、任务环境和独立 starter。首页的固定示例不随个人运行更新。

```text
site/lab/                       浏览器工作台和纯前端回放器
local_lab/server.py             本机任务分发、MCP 工具和真实事件记录
legalgym-agent-starter/          独立进程，连接自己的模型和 agent
.run/lab/<run-id>/               每次运行的案卷、事件、截图及 Word
```

## 模式一 本机联机运行

从本仓库目录启动两个终端进程：

```bash
.venv/bin/python local_lab/server.py --port 8841
```

在另一个终端配置模型密钥（参照 starter 的 `.env.example`，不要提交真实密钥），再运行：

```bash
python3 legalgym-agent-starter/starter.py --server http://127.0.0.1:8841
```

打开 `http://127.0.0.1:8841/lab/`。网页创建任务，starter 领取任务并自主调用本机 MCP 环境。
执行时展示日志和截图；结束后在同一页的“本次交互回放”中逐步查看、自动播放、回看证据，并在“合同交付”中翻阅全部 Word 页面。

浏览器不直接执行 Python，也不持有模型密钥。当前 Word 排版由本机文档渲染器完成，浏览器显示已经生成的页面图片。

## 模式二 纯静态网页回放

不必把 agent 部署到云端，也不必先把记录上传网站。agent 在自己的电脑上运行即可。

1. 在运行详情点击“导出回放包”，或直接取 `.run/lab/<run-id>/portable-replay.legalgym.json`。
   Starter 也会自动下载一份到 `legalgym-agent-starter/runs/`（可用 `--replay-dir` 改位置）。
2. 打开任意静态托管的 `site/lab/`，点击“导入回放记录”，选择该文件。
3. 本页在浏览器本地重建步骤、截图、条款对照和 Word 翻页；原 Word 也可以下载。

该模式没有后端依赖。导入不会上传文件，不执行包内脚本，不计算正式成绩。记录只保存在当前浏览器页面内存，刷新后重新导入。
浏览器仍需要先得到回放数据：本地文件选择、随静态站点一起分发的示例包，或以后实现的在线记录地址。

本目录自带一份真实独立 starter 运行的导出示例，位于 `site/lab/examples/c06-external-starter.legalgym.json`。
静态 HTTP 托管时，可用“载入已导出的示例回放”；直接通过 `file://` 打开 HTML 时，使用文件选择器导入示例。

如需验证纯静态模式，可启动一个只有文件托管功能的服务器（不启动 `local_lab/server.py`）：

```bash
python3 -m http.server 8850 --directory site
```

打开 `http://127.0.0.1:8850/lab/`，导入记录。此文件服务器不执行 agent，不提供任务 API。

## 导出包内容

使用 `legalgym.replay.v1` JSON 格式，包含运行元数据、统一事件、任务、合同、提交结果、PNG 页面与截图，以及 DOCX 的 Base64 数据。
页面图片与 Word 的关系由源文件 SHA-256 标记。文件限 64 MB，仅接受 PNG 和 DOCX 附件，不接收可执行 HTML/JS。
导入记录为开发者提供的回放，不等同于官方验证结果；正式榜单需要独立的评测和可信执行机制。

修改 starter 后可运行 `python3 local_lab/package_starter.py`，更新静态网页中的 starter 下载包。
