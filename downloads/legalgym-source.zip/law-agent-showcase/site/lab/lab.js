"use strict";
const $=id=>document.getElementById(id);
const statuses={queued:"等待领取",running:"运行中",finalizing:"正在生成交付物",stopping:"正在停止",completed:"已完成",failed:"运行失败",stopped:"已停止",interrupted:"已中断"};
const active=status=>["queued","running","finalizing","stopping"].includes(status);
const toolNames={read_contract:"读取原合同",browse:"浏览案例资料",submit:"提交合同修订"};
let state={agents:[],runs:[]},liveRuns=[],selected=new URLSearchParams(location.search).get("run"),stream,events=[],activeRun,backend=null,mountedReplay="";
const imports=new Map(),cache=new Map(),pending=new Map();
const replay=new window.LegalGymReplay($("inline-replay")),wordPager=new window.LegalGymWordPager($("word-pages"));
let command="";
function node(tag,text,cls){const e=document.createElement(tag);if(text!==undefined)e.textContent=text;if(cls)e.className=cls;return e;}
function notice(text){$("notice").textContent=text;$("notice").hidden=!text;}
async function api(path,data,method){const response=await fetch(path,method?{method}:data===undefined?{}:{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(data)});if(!response.ok){let message="无法连接本机后端";try{message=(await response.json()).error||message;}catch{}throw Error(message);}return response.json();}
function duration(s){s=Math.max(0,Math.round(s||0));return s>=60?`${Math.floor(s/60)} 分 ${s%60} 秒`:`${s} 秒`;}
function mergeRuns(){state.runs=[...[...imports.values()].map(x=>x.run),...liveRuns];}
function setMode(live){backend=live;$("runtime-mode").textContent=live?"本机联机模式":"静态回放模式";$("open-local-lab").hidden=live;$("reconnect-backend").hidden=live;command=`python3 legalgym-agent-starter/starter.py --server ${live?location.origin:"http://127.0.0.1:8841"}`;$("starter-command").textContent=command;}
function renderAgents(){
  const select=$("agent-select"),old=select.value,online=state.agents.filter(a=>a.online);select.replaceChildren();
  if(!backend){$("setup").open=true;select.append(new Option("静态模式：请先打开本机运行页",""));$("connection-status").textContent="当前仅查看回放。可导入本机导出的记录包；启动任务请打开本机运行页。";}
  else if(!online.length){select.append(new Option("等待 starter 连接",""));$("connection-status").textContent="后端在线，等待独立 starter 连接。";$("setup").open=true;}
  else{for(const a of online)select.append(new Option(`${a.name} · ${a.currentRun?"执行中":"可领取任务"}`,a.id));if(online.some(a=>a.id===old))select.value=old;$("connection-status").textContent=`${online.length} 个 Agent 已连接 · ${online.map(a=>a.model).join(" / ")}`;}
  updateStart();
}
function updateStart(){const a=state.agents.find(a=>a.id===$("agent-select").value);$("start-run").disabled=!backend||!a?.online||!!a.currentRun;}
function renderHistory(){
  $("run-count").textContent=state.runs.length;const list=$("run-list");list.replaceChildren();
  if(!state.runs.length){list.append(node("p","连接本机 Agent 开始运行，或从上方导入已有回放记录。","muted"));return;}
  for(const r of state.runs){const b=node("button",undefined,"history-item");b.type="button";b.setAttribute("aria-current",String(r.id===selected));b.append(node("strong",r.agentName+(r.imported?" · 已导入":"")),node("small",new Date(r.createdAt).toLocaleString("zh-CN")),node("small",r.originalRunId||r.id),node("span",`${statuses[r.status]||r.status} · ${duration(r.elapsedSeconds)}`,"history-status"));if(r.failureSummary)b.append(node("small",r.failureSummary,"history-failure"));b.onclick=()=>selectRun(r.id);list.append(b);}
}
function packetKey(run){return run.id+":"+run.eventCount+":"+(run.document?.renderedAt||"");}
function renderRun(run){
  $("tab-replay").dataset.ready=String(!active(run.status)&&run.eventCount>0);
  activeRun=run;$("empty-run").hidden=true;$("run-detail").hidden=false;$("run-id").textContent=(run.imported?"导入记录 · ":"")+(run.originalRunId||run.id);$("run-title").textContent=run.case;$("run-agent").textContent=`${run.agentName} · ${run.model} · ${run.agentVersion}${run.imported?" · 本地导入，非正式评测成绩":""}`;
  $("run-status").textContent=statuses[run.status]||run.status;$("run-status").dataset.status=run.status;$("run-duration").textContent=duration(run.elapsedSeconds);$("run-calls").textContent=run.toolCalls;$("run-errors").textContent=run.toolErrors;$("run-shots").textContent=run.screenshots;
  $("failure-summary").hidden=run.status!=="failed";$("failure-summary").textContent="失败原因："+(run.failureSummary||"请展开日志中的错误详情。");$("delete-run").hidden=active(run.status);
  const imported=imports.get(run.id);const logs=imported?.logUrl||run.logUrl;
  $("raw-log").href=logs;$("download-log").href=logs;$("download-log").download=(run.originalRunId||run.id)+".jsonl";
  $("export-replay").href=imported?.packageUrl||`/api/runs/${run.id}/replay-package`;$("export-replay").download=(run.originalRunId||run.id)+".legalgym.json";
  $("open-replay").hidden=active(run.status);$("stop-run").hidden=run.imported||!["queued","running","stopping"].includes(run.status);$("stop-run").disabled=run.status==="stopping";
  $("stream-status").textContent=run.imported?"本地记录已导入，无需后端":active(run.status)?"实时连接中":"记录已保存，可在本页回放";
  const packet=imported?.packet||cache.get(packetKey(run));if(packet)applyPacket(packet,run);else{ $("delivery-ready").hidden=true;$("delivery-wait").hidden=false;if(!active(run.status))loadPacket(run); }
}
function applyPacket(packet,run){
  if(selected!==run.id)return;const key=packetKey(run);
  if(mountedReplay!==key){replay.render(packet);mountedReplay=key;$("replay-message").hidden=true;}
  const word=packet.assets[packet.run.document?.wordPath||"assets/c06-contract-redline.docx"],ready=!!packet.submission&&!!word;
  $("tab-delivery").dataset.ready=String(ready);
  $("delivery-ready").hidden=!ready;$("delivery-wait").hidden=ready;
  $("delivery-wait").textContent=active(run.status)?"任务仍在执行，请先查看实时日志。":"本次未产生完整 Word 交付，可以在交互回放中检查操作与错误。";
  if(ready){$("delivery-word").href=word;const d=packet.run.document||{};const pages=(d.previewPages||[d.previewPath]).filter(Boolean).map(k=>packet.assets[k]).filter(Boolean);wordPager.update(pages);}
}
async function loadPacket(run){
  if(pending.has(run.id))return pending.get(run.id);const key=packetKey(run);
  const task=(async()=>{try{const packet=await api(`/api/runs/${run.id}/replay-data`);cache.set(key,packet);applyPacket(packet,run);}catch(e){if(selected===run.id){$("replay-message").hidden=false;$("replay-message").textContent="回放加载失败："+e.message;}}finally{pending.delete(run.id);}})();pending.set(run.id,task);return task;
}
function eventTitle(e){if(e.type==="tool_call"){const name=String(e.tool||"").replace("mcp__c06__","");if(name==="browse")return({home:"打开资料室",search:"查询企业",open:"打开资料记录"})[e.input?.action]||toolNames.browse;return toolNames[name]||name;}return({tool_result:e.status==="error"?"工具返回错误":"工具返回结果",agent_message:"Agent 进度",screenshot:"页面截图已保存",run_queued:"任务已创建",run_started:"Starter 开始执行",document_rendering:"正在生成 Word 全部页面",document_ready:"Word 页面已生成",run_finished:"运行结束",export_error:"交付检查失败",stop_requested:"请求停止"})[e.type]||e.type;}
function addEvent(e,assets){
  events.push(e);const item=node("article",undefined,"event");item.dataset.error=String(e.status==="error"||e.type==="export_error");const top=node("div",undefined,"event-top");top.append(node("strong",eventTitle(e)),node("time",new Date(e.time).toLocaleTimeString("zh-CN")));item.append(top,node("div",e.source==="agent"?"来源：Agent 自报消息":"来源：记录中的环境事件","event-source"));
  if(e.type==="tool_call"||e.type==="tool_result"){const d=node("details");d.open=e.status==="error";d.append(node("summary",e.type==="tool_call"?"查看调用参数":"查看返回内容"),node("pre",e.type==="tool_call"?JSON.stringify(e.input,null,2):e.result));item.append(d);}
  else if(e.type==="screenshot"){const src=assets?assets["screenshots/"+e.screenshot]:e.url;if(src){const shot={...e,url:src};const b=node("button",`查看截图：${e.title}`,"secondary");b.type="button";b.onclick=()=>{setTab("screens");showScreenshot(shot);$("page-records").scrollIntoView({block:"start"});};item.append(b);addScreenshot(shot);}}
  else if(e.message){if(e.message.length>280||e.type==="export_error"){const d=node("details");d.append(node("summary",e.type==="export_error"?"展开错误详情":"展开完整消息"),node("pre",e.message));item.append(d);}else item.append(node("p",e.message,"agent-text"));}
  $("event-log").append(item);if($("follow-log").checked)$("event-log").scrollTop=$("event-log").scrollHeight;
}
function addScreenshot(e){$("no-screens").hidden=true;const b=node("button",e.record||e.query||"资料室");b.type="button";b.dataset.seq=e.seq;b.onclick=()=>showScreenshot(e);$("screen-buttons").append(b);showScreenshot(e);}
function showScreenshot(e){$("screen-view").hidden=false;$("screen-image").src=e.url;$("screen-image").alt=e.title;$("screen-caption").textContent=e.title+" · "+new Date(e.capturedAt).toLocaleTimeString("zh-CN");$("screen-text").textContent=e.text;for(const b of $("screen-buttons").children)b.setAttribute("aria-pressed",String(b.dataset.seq==e.seq));}
function setTab(tab){if(tab==="screens"){tab="replay";$("page-records").open=true;}for(const b of document.querySelectorAll("[data-tab]")){const on=b.dataset.tab===tab;b.setAttribute("aria-selected",String(on));$("panel-"+b.dataset.tab).hidden=!on;}if(tab!=="replay")replay.stop();}
function selectRun(id){
  selected=id;history.replaceState(null,"","?run="+encodeURIComponent(id));if(stream)stream.close();replay.stop();mountedReplay="";events=[];$("event-log").replaceChildren();$("inline-replay").replaceChildren();$("screen-buttons").replaceChildren();$("screen-view").hidden=true;$("no-screens").hidden=false;$("replay-message").hidden=false;
  const run=state.runs.find(r=>r.id===id);if(!run)return;renderRun(run);renderHistory();
  const imported=imports.get(id);if(imported){for(const e of imported.packet.events)addEvent(e,imported.packet.assets);setTab("replay");return;}
  stream=new EventSource(`/api/runs/${id}/events`);
  stream.addEventListener("update",m=>{if(selected!==id)return;const data=JSON.parse(m.data);for(const e of data.events)if(!events.some(x=>x.seq===e.seq))addEvent(e);renderRun(data.run);if(!active(data.run.status))stream.close();const index=liveRuns.findIndex(r=>r.id===id);if(index>=0)liveRuns[index]=data.run;mergeRuns();renderHistory();});
  stream.onerror=()=>{if(activeRun?.id===id&&active(activeRun.status))$("stream-status").textContent="连接中断，正在重连…";};
}
async function refresh(force=false){
  if(backend===false&&!force)return;
  try{const data=await api("/api/state");setMode(true);state.agents=data.agents;liveRuns=data.runs;mergeRuns();renderAgents();renderHistory();if(!selected&&state.runs.length)selectRun(state.runs[0].id);else if(selected&&!activeRun&&state.runs.some(r=>r.id===selected))selectRun(selected);else{const run=state.runs.find(r=>r.id===selected);if(run)renderRun(run);}}
  catch{setMode(false);state.agents=[];liveRuns=[];mergeRuns();renderAgents();renderHistory();}
}
function decodeAsset(value){
  const match=/^data:(image\/png|application\/vnd\.openxmlformats-officedocument\.wordprocessingml\.document);base64,([A-Za-z0-9+/=]+)$/.exec(value);
  if(!match)throw Error("回放包包含不支持的附件格式，仅接受 PNG 和 Word 数据。");
  const raw=atob(match[2]),bytes=Uint8Array.from(raw,c=>c.charCodeAt(0));
  if(match[1]==="image/png"&&!(bytes[0]===137&&raw.slice(1,4)==="PNG"))throw Error("无效的 PNG 附件。");
  if(match[1]!=="image/png"&&raw.slice(0,2)!=="PK")throw Error("无效的 Word 附件。");
  return URL.createObjectURL(new Blob([bytes],{type:match[1]}));
}
async function importReplay(file){
  if(file.size>64*1024*1024)throw Error("回放包不能超过 64 MB。");const packet=JSON.parse(await file.text());
  if(packet.schema!=="legalgym.replay.v1"||!packet.run||typeof packet.run.id!=="string"||!Array.isArray(packet.events)||packet.events.length>10000||!packet.assets||typeof packet.assets!=="object")throw Error("请选择 LegalGym 导出的 .legalgym.json 回放包。");
  for(const e of packet.events){if(!e||typeof e.type!=="string"||!Number.isInteger(e.seq))throw Error("回放事件格式不正确。");if(e.type==="tool_call"&&(typeof e.tool!=="string"||!e.input||typeof e.input!=="object"))throw Error("工具调用记录格式不正确。");}
  if(packet.run.document?.previewPages&&!Array.isArray(packet.run.document.previewPages))throw Error("Word 页面列表格式不正确。");
  const entries=Object.entries(packet.assets);if(entries.length>256)throw Error("回放附件数量过多。");
  const urls=[],assets=Object.create(null);
  try{for(const [key,value] of entries){if(typeof value!=="string"||!key.match(/^(screenshots|assets)\/[A-Za-z0-9_.-]+$/))throw Error("回放附件路径不正确。");const url=decodeAsset(value);assets[key]=url;urls.push(url);}}
  catch(e){for(const url of urls)URL.revokeObjectURL(url);throw e;}
  packet.assets=assets;const original=packet.run,id="import-"+original.id;
  const elapsed=(Date.parse(original.finishedAt||original.createdAt)-Date.parse(original.startedAt||original.createdAt))/1000;
  const run={...original,id,originalRunId:original.id,imported:true,status:active(original.status)?"interrupted":original.status,elapsedSeconds:Math.max(0,elapsed||0),score:null};
  const logUrl=URL.createObjectURL(new Blob([packet.events.map(e=>JSON.stringify(e)).join("\n")],{type:"text/plain;charset=utf-8"})),packageUrl=URL.createObjectURL(file);urls.push(logUrl,packageUrl);
  const old=imports.get(id);if(old)for(const url of old.urls)URL.revokeObjectURL(url);
  imports.set(id,{run,packet,urls,logUrl,packageUrl});mergeRuns();selectRun(id);notice("已在浏览器本地导入回放，无需上传云端。此记录不作为正式评测成绩。");
}
$("delete-run").onclick=async()=>{
  const run=activeRun;if(!run||active(run.status))return;
  if(!confirm(run.imported?"移除这条导入记录？原始文件不会被删除。":"删除本次运行的日志、截图和交付文件？此操作不可撤销。"))return;
  try{if(run.imported){for(const url of imports.get(run.id).urls)URL.revokeObjectURL(url);imports.delete(run.id);}else await api(`/api/runs/${run.id}`,undefined,"DELETE");
    if(stream)stream.close();replay.stop();liveRuns=liveRuns.filter(r=>r.id!==run.id);for(const key of cache.keys())if(key.startsWith(run.id+":"))cache.delete(key);mergeRuns();selected=null;activeRun=null;renderHistory();if(state.runs.length)selectRun(state.runs[0].id);else{$("run-detail").hidden=true;$("empty-run").hidden=false;history.replaceState(null,"",location.pathname);}notice("记录已删除。");
  }catch(e){notice(e.message);}
};
$("agent-select").onchange=updateStart;
$("start-run").onclick=async()=>{const b=$("start-run");b.disabled=true;try{notice("");const run=await api("/api/runs",{agentId:$("agent-select").value});liveRuns.unshift(run);mergeRuns();selectRun(run.id);setTab("log");await refresh();}catch(e){notice(e.message);updateStart();}};
$("stop-run").onclick=async()=>{try{renderRun(await api(`/api/runs/${selected}/stop`,{}));}catch(e){notice(e.message);}};
$("copy-command").onclick=async()=>{try{await navigator.clipboard.writeText(command);$("copy-command").textContent="已复制";setTimeout(()=>$("copy-command").textContent="复制命令",1800);}catch{notice("请直接选择并复制上方命令。");}};
$("reconnect-backend").onclick=()=>refresh(true);
$("open-replay").onclick=()=>setTab("replay");
$("delivery-replay").onclick=()=>{setTab("replay");const index=replay.steps?.findIndex(s=>s.kind==="delivery");if(index>=0)replay.show(index);};
$("import-replay").onchange=async e=>{const file=e.target.files[0];if(!file)return;try{await importReplay(file);}catch(error){notice("导入失败："+error.message);}e.target.value="";};
async function loadExample(tab="replay"){
  try{const r=await fetch("examples/c06-external-starter.legalgym.json");if(!r.ok)throw Error("找不到示例文件");const blob=await r.blob();const metadata=JSON.parse(await blob.text());
    const existing=liveRuns.find(run=>run.id===metadata.run.id);
    if(existing)selectRun(existing.id);else await importReplay(new File([blob],"c06-external-starter.legalgym.json",{type:"application/json"}));
    setTab(tab);$("run-detail").scrollIntoView({block:"start"});notice("正在查看已完成的示例运行记录；此操作不会启动新的模型请求。");
  }catch(e){notice("请通过“导入回放记录”选择本文件夹 examples/ 中的示例包。"+e.message);}
}
$("load-example").onclick=()=>loadExample();
const tabs=[...document.querySelectorAll("[data-tab]")];for(const b of tabs){b.onclick=()=>setTab(b.dataset.tab);b.onkeydown=e=>{let i=tabs.indexOf(b);if(e.key==="ArrowRight")i=(i+1)%tabs.length;else if(e.key==="ArrowLeft")i=(i+tabs.length-1)%tabs.length;else return;e.preventDefault();tabs[i].focus();setTab(tabs[i].dataset.tab);};}
const initialTab=new URLSearchParams(location.search).get("tab");if(["log","replay","screens","delivery"].includes(initialTab))setTab(initialTab);
refresh().then(()=>{if(new URLSearchParams(location.search).get("example")==="1")return loadExample(initialTab||"log");});setInterval(()=>refresh(),3000);
