import base64
from concurrent.futures import ThreadPoolExecutor
import json
from pathlib import Path
import tempfile
import unittest
from local_lab.replay_bundle import build_replay, write_replay_package


class ReplayBundleTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name) / "run"
        (self.root / "workspace/trace").mkdir(parents=True)
        (self.root / "public/replay/assets").mkdir(parents=True)
        document = {"wordPath": "assets/result.docx", "previewPath": "assets/page-1.png",
                    "previewPages": ["assets/page-1.png", "assets/page-2.png"], "pageCount": 2}
        self.manifest = {"id": "sample", "status": "completed", "document": document, "score": 999,
                         "token": "not-for-export", "modelApiKey": "also-not-for-export"}
        (self.root / "manifest.json").write_text(json.dumps(self.manifest))
        (self.root / "workspace/TASK.md").write_text("test task")
        (self.root / "workspace/contract.json").write_text('{"clauses":[]}')
        events = [{"seq": 1, "type": "screenshot", "screenshot": "step-01.png"}]
        (self.root / "events.jsonl").write_text("\n".join(map(json.dumps, events)))
        self.png = base64.b64decode("iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+/lAAAAABJRU5ErkJggg==")
        for name in ["page-1.png", "page-2.png"]:
            (self.root / "public/replay/assets" / name).write_bytes(self.png)
        (self.root / "workspace/trace/step-01.png").write_bytes(self.png)
        (self.root / "public/replay/assets/result.docx").write_bytes(b"PK-test-word")

    def tearDown(self):
        self.temp.cleanup()

    def test_inline_packet_contains_all_pages_and_word_without_credentials(self):
        packet = build_replay(self.root, inline=True)
        self.assertEqual(packet["schema"], "legalgym.replay.v1")
        self.assertEqual(len(packet["assets"]), 4)
        self.assertTrue(packet["assets"]["assets/page-2.png"].startswith("data:image/png;base64,"))
        self.assertTrue(packet["assets"]["assets/result.docx"].endswith(base64.b64encode(b"PK-test-word").decode()))
        self.assertIsNone(packet["run"]["score"])
        serialized = json.dumps(packet)
        self.assertNotIn("not-for-export", serialized)

    def test_live_packet_points_to_run_scoped_assets(self):
        packet = build_replay(self.root)
        self.assertEqual(packet["assets"]["screenshots/step-01.png"], "/api/runs/sample/screenshots/step-01.png")
        self.assertEqual(packet["assets"]["assets/page-2.png"], "/api/runs/sample/replay/assets/page-2.png")

    def test_outside_paths_are_not_exported(self):
        (self.root / "secret.txt").write_text("must-not-appear")
        self.manifest["document"]["previewPages"].append("../../secret.txt")
        (self.root / "manifest.json").write_text(json.dumps(self.manifest))
        self.assertNotIn("must-not-appear", json.dumps(build_replay(self.root, inline=True)))

    def test_concurrent_download_exports_remain_valid(self):
        with ThreadPoolExecutor(max_workers=3) as pool:
            outputs = list(pool.map(lambda _: write_replay_package(self.root), range(3)))
        self.assertEqual(json.loads(outputs[0].read_text())["schema"], "legalgym.replay.v1")


if __name__ == "__main__":
    unittest.main()
