# 本机 Agent 实验室

这是一套本机开发验证服务，不是公网部署配置。保留现有宣传站，增加 `/lab/` 工作台。

## 启动

从仓库根目录运行：

```bash
.venv/bin/python local_lab/server.py --port 8840
```

在另一个终端配置模型环境变量，运行独立 starter：

```bash
python3 legalgym-agent-starter/starter.py --server http://127.0.0.1:8841
```

配置方式见 `legalgym-agent-starter/README.md`。打开 `http://127.0.0.1:8841/lab/`，选择已连接的 agent，再点击“开始运行”。
后端不会自行启动 agent，也不会读取模型密钥；starter 领取网页创建的任务后独立执行。

## 本机 API

- `POST /api/agents/register`：starter 注册并取得本机配对令牌。
- `GET /api/agents/{id}/job`：带令牌领取任务；无任务时长轮询。
- `POST /api/runs`：网页创建任务。
- `POST /api/runs/{id}/mcp`：运行级 MCP JSON-RPC 工具入口；初始化、工具发现、调用。
- `POST /api/runs/{id}/agent-events`：starter 自报进度，与环境记录区分。
- `GET /api/runs/{id}/events`：网页使用的 SSE 事件流。
- `POST /api/runs/{id}/finish`：starter 报告结束；后端检查实际交付并导出 replay。
- `DELETE /api/runs/{id}`：删除已结束运行的日志、截图与交付物；进行中的任务拒绝删除。
- `POST /api/runs/{id}/stop`：阻止后续工具调用，请求 starter 停止。
- `GET /api/runs/{id}/logs`：完整原始事件日志，声明 UTF-8。
- `GET /api/runs/{id}/replay-data`：同页回放所用的结构化记录与附件地址。
- `GET /api/runs/{id}/replay-package`：自包含 JSON 回放包，可在静态网页本地导入。

事件和案卷保存在 `.run/lab/<run-id>/`；日志不含模型密钥。
交付完成后自动从导出的 `.docx` 渲染全部页面 PNG，在运行详情本页的交互回放和合同交付中可左右翻页，并下载原 Word。预览保留修订痕迹；批注以 Word 文件中的内容为准。
本机渲染器路径在忽略 Git 的 `.local-runtime/doc-preview-config.json` 中配置（`python`、`script`、`bin`、可选 `fontconfig`）。也可用 `LEGALGYM_RENDER_PYTHON`、`LEGALGYM_RENDER_SCRIPT`、`LEGALGYM_FONTCONFIG` 环境变量指定。
未配置或渲染失败时，仍保留 Word 下载，界面明确显示预览不可用。预览元数据包含源 Word 的 SHA-256，用于确认页面图像对应本次文件。
每次运行使用独立案卷副本；原始案例和宣传站中的既有演示数据不被覆盖。
文件级回放由现有导出器生成，统一事件格式兼容原先的 dsh 导出；新 starter 不依赖 dsh。

这版使用 loopback、Origin/Host 检查及 starter 令牌，未实现公网账号、计费、正式评分或防篡改评测。
模型超时、starter 断开和停止请求在界面及日志中展示；断线不自动伪造完成或生成成绩。
