"""Render the exported DOCX with the configured document runtime, preserving the original."""
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess

ROOT = Path(__file__).resolve().parent.parent


def render_word_preview(docx_path, run_dir):
    docx_path, run_dir = Path(docx_path), Path(run_dir)
    fingerprint = hashlib.sha256(docx_path.read_bytes()).hexdigest()
    metadata = {"wordPath": "assets/" + docx_path.name, "sourceSha256": fingerprint,
                "previewState": "unavailable", "previewPath": None, "previewPages": []}
    config_path = ROOT / ".local-runtime/doc-preview-config.json"
    try:
        config = json.loads(config_path.read_text(encoding="utf-8")) if config_path.is_file() else {}
    except (OSError, ValueError):
        metadata["previewMessage"] = "文档渲染器配置暂不可用，仍可下载修订 Word。"
        return metadata
    python = os.environ.get("LEGALGYM_RENDER_PYTHON") or config.get("python")
    script = os.environ.get("LEGALGYM_RENDER_SCRIPT") or config.get("script")
    if not python or not script or not Path(python).is_file() or not Path(script).is_file():
        metadata["previewMessage"] = "未配置文档渲染器，仍可下载修订 Word。"
        return metadata
    output = run_dir / "word-render" / fingerprint[:16]
    output.mkdir(parents=True, exist_ok=True)
    env = dict(os.environ)
    bins = config.get("bin")
    if bins:
        env["PATH"] = bins + os.pathsep + env.get("PATH", "")
        env["CODEX_RUNTIME_BIN"] = bins
    fonts = os.environ.get("LEGALGYM_FONTCONFIG") or config.get("fontconfig")
    if fonts:
        env["FONTCONFIG_FILE"] = fonts
    command = [python, script, str(docx_path.resolve()), "--output_dir", str(output.resolve()),
               "--width", "1200", "--height", "1600", "--emit_pdf"]
    try:
        result = subprocess.run(command, env=env, capture_output=True, text=True, timeout=120)
        (output / "render.log").write_text(result.stdout + result.stderr, encoding="utf-8")
        pages = sorted(output.glob("page-*.png"), key=lambda p: int(p.stem.split("-")[-1]))
        if result.returncode or not pages:
            metadata.update(previewState="failed", previewMessage="页面预览生成失败，仍可下载修订 Word。")
            return metadata
        preview_pages = []
        for index, page in enumerate(pages, 1):
            filename = docx_path.stem + f"-page-{index}.png"
            shutil.copyfile(page, docx_path.parent / filename)
            preview_pages.append("assets/" + filename)
        metadata.update(previewState="ready", previewPath=preview_pages[0], previewPages=preview_pages, pageCount=len(pages),
                        renderedAt=datetime.now(timezone.utc).isoformat(timespec="seconds"))
        (output / "preview.json").write_text(json.dumps(metadata, ensure_ascii=False, indent=2), encoding="utf-8")
    except (OSError, subprocess.TimeoutExpired) as error:
        metadata.update(previewState="failed", previewMessage="页面预览暂不可用，仍可下载修订 Word。")
        (output / "render.log").write_text(type(error).__name__, encoding="utf-8")
    return metadata
