"""Loopback-only LegalGym task hub; the agent loop runs in a separate starter process."""
import argparse
import functools
import http.server
import importlib.util
import io
import json
import os
from pathlib import Path
import secrets
import shutil
import sys
import threading
import time
from datetime import datetime, timezone
from urllib.parse import urlparse, parse_qs
import uuid
import zipfile

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
from export_run import export
from local_lab.replay_bundle import build_replay, write_replay_package


def now():
    return datetime.now(timezone.utc).isoformat(timespec="milliseconds")


def write_json(path, value):
    temp = path.with_suffix(path.suffix + ".tmp")
    temp.write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding="utf-8")
    temp.replace(path)


def validate(value, schema, path="arguments"):
    kind = schema.get("type")
    types = {"object": dict, "array": list, "string": str}
    if kind in types and not isinstance(value, types[kind]):
        raise ValueError(f"{path}: expected {kind}")
    if "enum" in schema and value not in schema["enum"]:
        raise ValueError(f"{path}: expected one of {schema['enum']}")
    if kind == "object":
        fields = schema.get("properties", {})
        for key in schema.get("required", []):
            if key not in value:
                raise ValueError(f"{path}: missing {key}")
        for key, item in value.items():
            if key not in fields and schema.get("additionalProperties") is False:
                raise ValueError(f"{path}: unknown field {key}")
            if key in fields:
                validate(item, fields[key], path + "." + key)
    if kind == "array":
        if len(value) < schema.get("minItems", 0):
            raise ValueError(f"{path}: not enough items")
        for index, item in enumerate(value):
            validate(item, schema.get("items", {}), f"{path}[{index}]")
    if kind == "string" and len(value) < schema.get("minLength", 0):
        raise ValueError(f"{path}: empty string")


class Hub:
    def __init__(self, origin, root=None):
        self.root = Path(root) if root is not None else ROOT / ".run/lab"
        self.root.mkdir(parents=True, exist_ok=True)
        self.origin = origin
        self.condition = threading.Condition(threading.RLock())
        self.agents = {}
        self.runs = {}
        self.modules = {}
        self.locks = {}
        for file in self.root.glob("*/manifest.json"):
            try:
                run = json.loads(file.read_text(encoding="utf-8"))
                if run["status"] in {"queued", "running", "finalizing", "stopping"}:
                    run.update(status="interrupted", finishedAt=now())
                    write_json(file, run)
                self.runs[run["id"]] = run
            except (ValueError, KeyError):
                pass

    def save(self, run):
        with self.condition:
            write_json(self.root / run["id"] / "manifest.json", run)

    def event(self, run, kind, source="environment", **data):
        with self.condition:
            run["eventCount"] = run.get("eventCount", 0) + 1
            event = {"seq": run["eventCount"], "time": now(), "type": kind, "source": source, **data}
            with (self.root / run["id"] / "events.jsonl").open("a", encoding="utf-8") as stream:
                stream.write(json.dumps(event, ensure_ascii=False) + "\n")
            self.save(run)
            self.condition.notify_all()
            return event

    def register(self, data):
        agent_id = uuid.uuid4().hex
        token = secrets.token_urlsafe(32)
        with self.condition:
            self.agents[agent_id] = {"id": agent_id, "name": str(data.get("name", "External agent"))[:100],
                "model": str(data.get("model", "unspecified"))[:150], "version": str(data.get("version", "unknown"))[:80],
                "token": token, "lastSeen": time.time(), "currentRun": None}
        return {"id": agent_id, "token": token}

    def authenticate(self, agent_id, token):
        agent = self.agents.get(agent_id)
        if not agent or not secrets.compare_digest(agent["token"], token):
            raise PermissionError("Invalid starter token")
        agent["lastSeen"] = time.time()
        return agent

    def failure_summary(self, run):
        if run.get("status") != "failed":
            return ""
        if run.get("failureSummary"):
            return run["failureSummary"]
        path = self.root / run["id"] / "events.jsonl"
        rows = [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line.strip()] if path.exists() else []
        messages = [str(e.get("message", "")) for e in rows if e.get("type") in {"export_error", "run_finished"}]
        if any("<tool_call>" in m and "submit" in m for m in messages) and not (self.root / run["id"] / "workspace/submission.json").exists():
            return "模型把 submit 写成了普通文本，未实际调用提交工具，因此没有生成交付物。"
        if any("submission.json" in m and "No such file" in m for m in messages):
            return "缺少 submission.json：未生成有效提交，无法导出交付物。"
        message = next((m for m in messages if m.strip()), "未收到有效交付；请展开日志查看详情。")
        return message.splitlines()[0][:180]

    def delete_run(self, run_id):
        with self.condition:
            run = self.runs[run_id]
            if run["status"] in {"queued", "running", "finalizing", "stopping"}:
                raise ValueError("请先停止运行，结束后才能删除记录。")
            directory = (self.root / run_id).resolve()
            if directory.parent != self.root.resolve():
                raise ValueError("Invalid run directory")
            shutil.rmtree(directory)
            del self.runs[run_id]
            self.modules.pop(run_id, None)
            self.locks.pop(run_id, None)
            self.condition.notify_all()
            return {"deleted": run_id}

    def summary(self, run):
        data = dict(run)
        data["failureSummary"] = self.failure_summary(run)
        base = "/api/runs/" + run["id"]
        data.update(logUrl=base + "/logs", replayUrl=base + "/replay/" if run.get("replayReady") else None)
        data["elapsedSeconds"] = round((datetime.fromisoformat(run.get("finishedAt") or now()) -
                                        datetime.fromisoformat(run.get("startedAt") or run["createdAt"])).total_seconds(), 1)
        return data

    def create_run(self, agent_id):
        with self.condition:
            agent = self.agents.get(agent_id)
            if not agent or time.time() - agent["lastSeen"] > 25:
                raise ValueError("请先启动并连接 starter。")
            if agent["currentRun"]:
                raise ValueError("该 Agent 正在执行任务，请等待结束。")
            run_id = datetime.now().strftime("c06-%Y%m%d-%H%M%S-") + uuid.uuid4().hex[:6]
            directory = self.root / run_id
            shutil.copytree(ROOT / "case", directory / "workspace")
            (directory / "workspace/.mock-origin").write_text(self.origin, encoding="utf-8")
            run = {"id": run_id, "agentId": agent_id, "agentName": agent["name"], "model": agent["model"],
                "agentVersion": agent["version"], "case": "C06 · 临汀工程咨询合同", "caseVersion": "c06-local-v1",
                "status": "queued", "createdAt": now(), "eventCount": 0, "replayReady": False,
                "toolCalls": 0, "toolErrors": 0, "screenshots": 0, "score": None}
            self.runs[run_id] = run
            self.locks[run_id] = threading.Lock()
            agent["currentRun"] = run_id
            write_json(directory / "run-info.json", {"harness": "external-starter", "model": agent["model"],
                       "provider": "user-configured", "agentName": agent["name"], "agentVersion": agent["version"]})
            self.event(run, "run_queued", message="任务已创建，等待外部 starter 领取。")
            return self.summary(run)

    def next_job(self, agent):
        with self.condition:
            deadline = time.monotonic() + 10
            while time.monotonic() < deadline:
                agent["lastSeen"] = time.time()
                run = self.runs.get(agent["currentRun"])
                if run and run["status"] == "queued":
                    run.update(status="running", startedAt=now())
                    self.event(run, "run_started", message="独立 starter 已领取任务。")
                    return {"runId": run["id"], "task": (self.root / run["id"] / "workspace/TASK.md").read_text(encoding="utf-8"),
                            "mcpUrl": f"/api/runs/{run['id']}/mcp"}
                self.condition.wait(timeout=1)
            return {"job": None}

    def module(self, run):
        if run["id"] not in self.modules:
            spec = importlib.util.spec_from_file_location("case_" + run["id"].replace("-", "_"),
                      self.root / run["id"] / "workspace/mcp_server.py")
            module = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(module)
            self.modules[run["id"]] = module
        return self.modules[run["id"]]

    def mcp(self, run, request):
        method = request.get("method")
        params = request.get("params", {})
        request_id = request.get("id")
        if method == "notifications/initialized":
            return None
        if method == "initialize":
            result = {"protocolVersion": "2025-11-25", "capabilities": {"tools": {}},
                      "serverInfo": {"name": "legalgym-local", "version": "0.1.0"}}
        elif method == "ping":
            result = {}
        elif method == "tools/list":
            result = {"tools": self.module(run).TOOLS}
        elif method == "tools/call":
            if run["status"] != "running":
                raise ValueError("Run is not running")
            name, arguments = params.get("name"), params.get("arguments", {})
            call_id = uuid.uuid4().hex
            started = time.monotonic()
            with self.locks[run["id"]]:
                run["toolCalls"] += 1
                self.event(run, "tool_call", callId=call_id, tool="mcp__c06__" + str(name), input=arguments)
                try:
                    module = self.module(run)
                    definition = next((t for t in module.TOOLS if t["name"] == name), None)
                    if not definition:
                        raise ValueError("Unknown tool")
                    validate(arguments, definition["inputSchema"])
                    text = module.call_tool(name, arguments)
                    result = {"content": [{"type": "text", "text": text}]}
                    status = "completed"
                except Exception as error:
                    text = str(error)
                    result = {"isError": True, "content": [{"type": "text", "text": text}]}
                    status = "error"
                    run["toolErrors"] += 1
                self.event(run, "tool_result", callId=call_id, status=status, result=text,
                           durationMs=round((time.monotonic() - started) * 1000))
                trace = self.root / run["id"] / "workspace/trace/browser.jsonl"
                if name == "browse" and status == "completed" and trace.exists():
                    entry = json.loads(trace.read_text(encoding="utf-8").splitlines()[-1])
                    run["screenshots"] += 1
                    self.event(run, "screenshot", **entry,
                        url=f"/api/runs/{run['id']}/screenshots/{entry['screenshot']}")
            self.save(run)
        else:
            return {"jsonrpc": "2.0", "id": request_id, "error": {"code": -32601, "message": "Unknown method"}}
        return {"jsonrpc": "2.0", "id": request_id, "result": result}

    def finish(self, run, data):
        if run["status"] not in {"running", "stopping"}:
            raise ValueError("Run already finished")
        if run["status"] == "stopping":
            status = "stopped"
        else:
            status = "completed" if data.get("status") == "completed" else "failed"
        if status == "completed":
            run["status"] = "finalizing"
            self.event(run, "document_rendering", message="正在导出修订 Word，并从该文件渲染全部页面。")
            target = self.root / run["id"] / "public/replay"
            try:
                shutil.copytree(ROOT / "site", target)
                # Each run includes only its own screenshots.
                shutil.rmtree(target / "assets/replay", ignore_errors=True)
                export(self.root / run["id"], target)
                run["replayReady"] = True
                payload = json.loads((target / "run-data.js").read_text(encoding="utf-8").removeprefix("window.C06_RUN = ").rstrip(";\n"))
                run["document"] = payload.get("document")
                if run["document"] and run["document"].get("previewState") == "ready":
                    self.event(run, "document_ready", message="修订 Word 全部页面已生成，可以左右翻页或下载。")
            except Exception as error:
                status = "failed"
                shutil.rmtree(target, ignore_errors=True)
                self.event(run, "export_error", message=str(error))
        run.update(status=status, finishedAt=now())
        self.event(run, "run_finished", status=status, message=str(data.get("message", ""))[:2000])
        if status == "failed":
            run["failureSummary"] = self.failure_summary(run)
            self.save(run)
        try:
            write_replay_package(self.root / run["id"])
        except (OSError, ValueError) as error:
            print("Portable replay export:", type(error).__name__, flush=True)
        agent = self.agents.get(run["agentId"])
        if agent:
            agent["currentRun"] = None
        return self.summary(run)


class Handler(http.server.SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=str(ROOT / "site"), **kwargs)

    def log_message(self, format, *args):
        if not self.path.startswith("/api/agents"):
            super().log_message(format, *args)

    @property
    def hub(self):
        return self.server.hub

    def json(self, data, status=200):
        payload = json.dumps(data, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Cache-Control", "no-store")
        self.send_header("Content-Length", str(len(payload)))
        self.end_headers()
        self.wfile.write(payload)

    def agent(self, agent_id):
        token = self.headers.get("Authorization", "").removeprefix("Bearer ")
        return self.hub.authenticate(agent_id, token)

    def valid_host(self):
        host = self.headers.get("Host", "")
        if host not in {f"127.0.0.1:{self.server.server_port}", f"localhost:{self.server.server_port}"}:
            self.json({"error": "Loopback host required"}, 403)
            return False
        origin = self.headers.get("Origin")
        if origin and origin not in {f"http://127.0.0.1:{self.server.server_port}", f"http://localhost:{self.server.server_port}"}:
            self.json({"error": "Origin rejected"}, 403)
            return False
        return True

    def do_GET(self):
        if not self.valid_host():
            return
        route = urlparse(self.path)
        parts = route.path.strip("/").split("/")
        try:
            if route.path == "/api/state":
                with self.hub.condition:
                    agents = [{k: v for k, v in a.items() if k != "token"} | {"online": time.time() - a["lastSeen"] < 25}
                              for a in self.hub.agents.values()]
                    snapshot = {"agents": agents, "runs": [self.hub.summary(r) for r in reversed(list(self.hub.runs.values()))],
                                "mode": "local", "serverTime": now()}
                return self.json(snapshot)
            if route.path == "/api/starter.zip":
                buffer = io.BytesIO()
                with zipfile.ZipFile(buffer, "w", zipfile.ZIP_DEFLATED) as archive:
                    for path in (ROOT / "legalgym-agent-starter").iterdir():
                        if path.is_file() and (path.suffix in {".py", ".md", ".example"} or path.name == ".gitignore"):
                            archive.write(path, "legalgym-agent-starter/" + path.name)
                content = buffer.getvalue()
                self.send_response(200)
                self.send_header("Content-Type", "application/zip")
                self.send_header("Content-Disposition", 'attachment; filename="legalgym-agent-starter.zip"')
                self.send_header("Content-Length", str(len(content)))
                self.end_headers()
                return self.wfile.write(content)
            if len(parts) == 4 and parts[:2] == ["api", "agents"] and parts[3] == "job":
                return self.json(self.hub.next_job(self.agent(parts[2])))
            if len(parts) >= 3 and parts[:2] == ["api", "runs"]:
                run = self.hub.runs[parts[2]]
                directory = self.hub.root / run["id"]
                if len(parts) == 3:
                    return self.json(self.hub.summary(run))
                if parts[3] == "replay-data":
                    return self.json(build_replay(directory))
                if parts[3] == "replay-package":
                    package = write_replay_package(directory)
                    content = package.read_bytes()
                    self.send_response(200)
                    self.send_header("Content-Type", "application/json; charset=utf-8")
                    self.send_header("Content-Disposition", f'attachment; filename="{run["id"]}.legalgym.json"')
                    self.send_header("Content-Length", str(len(content)))
                    self.end_headers()
                    return self.wfile.write(content)
                if parts[3] == "events":
                    after = int(parse_qs(route.query).get("after", [0])[0])
                    self.send_response(200)
                    self.send_header("Content-Type", "text/event-stream; charset=utf-8")
                    self.send_header("Cache-Control", "no-cache")
                    self.end_headers()
                    try:
                        while True:
                            with self.hub.condition:
                                rows = [json.loads(l) for l in (directory / "events.jsonl").read_text(encoding="utf-8").splitlines()]
                                events = [e for e in rows if e["seq"] > after]
                                payload = json.dumps({"run": self.hub.summary(run), "events": events}, ensure_ascii=False)
                                self.wfile.write(("event: update\ndata: " + payload + "\n\n").encode("utf-8"))
                                self.wfile.flush()
                                if events:
                                    after = events[-1]["seq"]
                                if run["status"] not in {"queued", "running", "finalizing", "stopping"}:
                                    break
                                self.hub.condition.wait(timeout=8)
                    except (BrokenPipeError, ConnectionResetError):
                        pass
                    return
                if parts[3] == "logs":
                    content = (directory / "events.jsonl").read_bytes()
                    self.send_response(200)
                    self.send_header("Content-Type", "text/plain; charset=utf-8")
                    self.send_header("Content-Length", str(len(content)))
                    self.end_headers()
                    return self.wfile.write(content)
                if parts[3] == "screenshots" and len(parts) == 5:
                    if not (parts[4].startswith("step-") and parts[4].endswith(".png")):
                        raise KeyError("Screenshot not found")
                    return self.file(directory / "workspace/trace", parts[4])
                if parts[3] == "replay" and run.get("replayReady"):
                    if len(parts) > 4 and parts[4] == "lab":
                        self.send_response(302)
                        self.send_header("Location", "/lab/?run=" + run["id"])
                        self.end_headers()
                        return
                    if not route.path.endswith("/") and len(parts) == 4:
                        self.send_response(302)
                        self.send_header("Location", route.path + "/")
                        self.end_headers()
                        return
                    return self.file(directory / "public/replay", "/".join(parts[4:]) or "index.html")
                if parts[3] == "mcp":
                    self.send_response(405)
                    self.send_header("Allow", "POST")
                    self.end_headers()
                    return
                raise KeyError("Endpoint not found")
            return super().do_GET()
        except (KeyError, FileNotFoundError):
            self.json({"error": "Not found"}, 404)
        except PermissionError as error:
            self.json({"error": str(error)}, 403)
        except ValueError as error:
            self.json({"error": str(error)}, 400)

    def file(self, root, name):
        path = (root / name).resolve()
        if not path.is_relative_to(root.resolve()) or not path.is_file():
            raise FileNotFoundError()
        content = path.read_bytes()
        content_type = self.guess_type(str(path))
        if content_type.startswith("text/") or content_type in {"application/javascript", "application/json"}:
            content_type += "; charset=utf-8"
        self.send_response(200)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(content)))
        self.end_headers()
        self.wfile.write(content)

    def do_DELETE(self):
        if not self.valid_host():
            return
        parts = urlparse(self.path).path.strip("/").split("/")
        if len(parts) != 3 or parts[:2] != ["api", "runs"]:
            return self.json({"error": "Not found"}, 404)
        try:
            return self.json(self.hub.delete_run(parts[2]))
        except KeyError:
            return self.json({"error": "Record not found"}, 404)
        except ValueError as error:
            return self.json({"error": str(error)}, 409)

    def do_POST(self):
        if not self.valid_host():
            return
        try:
            length = int(self.headers.get("Content-Length", 0))
            if length > 2_000_000:
                return self.json({"error": "Request too large"}, 413)
            data = json.loads(self.rfile.read(length) or b"{}")
            parts = urlparse(self.path).path.strip("/").split("/")
            if parts == ["api", "agents", "register"]:
                return self.json(self.hub.register(data))
            if parts == ["api", "runs"]:
                return self.json(self.hub.create_run(data["agentId"]), 201)
            if len(parts) == 4 and parts[:2] == ["api", "agents"] and parts[3] == "heartbeat":
                self.agent(parts[2])
                return self.json({"ok": True})
            if len(parts) == 4 and parts[:2] == ["api", "runs"]:
                run = self.hub.runs[parts[2]]
                if parts[3] == "stop":
                    if run["status"] == "queued":
                        run.update(status="stopped", finishedAt=now())
                        self.hub.agents[run["agentId"]]["currentRun"] = None
                        self.hub.event(run, "run_finished", status="stopped", message="任务在领取前停止。")
                    elif run["status"] == "running":
                        run["status"] = "stopping"
                        self.hub.event(run, "stop_requested", message="已请求停止；等待当前模型请求返回。")
                    return self.json(self.hub.summary(run))
                self.agent(run["agentId"])
                if parts[3] == "mcp":
                    response = self.hub.mcp(run, data)
                    if response is None:
                        self.send_response(202)
                        self.end_headers()
                        return
                    return self.json(response)
                if parts[3] == "agent-events":
                    if run["status"] not in {"running", "stopping"}:
                        raise ValueError("Run is not running")
                    # Agent-supplied messages are distinct from environment-observed calls.
                    message = str(data.get("message", ""))[:16000]
                    self.hub.event(run, "agent_message", source="agent", message=message,
                                   usage=data.get("usage"))
                    return self.json({"ok": True})
                if parts[3] == "finish":
                    return self.json(self.hub.finish(run, data))
            self.json({"error": "Not found"}, 404)
        except PermissionError as error:
            self.json({"error": str(error)}, 403)
        except (ValueError, KeyError) as error:
            self.json({"error": str(error)}, 400)
        except Exception as error:
            self.json({"error": str(error)}, 500)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--port", type=int, default=8841)
    args = parser.parse_args()
    chrome = Path("/Applications/Google Chrome.app/Contents/MacOS/Google Chrome")
    if chrome.exists():
        os.environ.setdefault("C06_CHROMIUM", str(chrome))
    mock = http.server.ThreadingHTTPServer(("127.0.0.1", 0),
             functools.partial(http.server.SimpleHTTPRequestHandler, directory=str(ROOT / "site/mock")))
    threading.Thread(target=mock.serve_forever, daemon=True).start()
    server = http.server.ThreadingHTTPServer(("127.0.0.1", args.port), Handler)
    server.hub = Hub(f"http://127.0.0.1:{mock.server_port}")
    print(f"LegalGym 实验室：http://127.0.0.1:{server.server_port}/lab/", flush=True)
    print("仅供本机验证。Agent 在独立 starter 进程中运行；无正式法律质量评分。", flush=True)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()
        mock.shutdown()


if __name__ == "__main__":
    main()
