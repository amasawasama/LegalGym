"""Create allowlisted static and source archives, excluding private local state."""
from pathlib import Path
import zipfile

ROOT = Path(__file__).resolve().parent.parent
DENIED = {'.git', '.run', '.venv', '.local-runtime', '__pycache__', '.DS_Store', 'runs', '.env'}


def public_files(folder):
    for path in sorted(folder.rglob('*')):
        if path.is_file() and not any(part in DENIED for part in path.relative_to(ROOT).parts):
            yield path


def main():
    output = ROOT / '.run/distribution'
    output.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(output / 'legalgym-pages.zip', 'w', zipfile.ZIP_DEFLATED) as archive:
        for path in public_files(ROOT / 'site'):
            archive.write(path, path.relative_to(ROOT / 'site'))
    files = []
    for directory in ('site', 'case', 'local_lab', 'legalgym-agent-starter', '.github'):
        files.extend(public_files(ROOT / directory))
    files.extend(ROOT / name for name in ('README.md', 'LOCAL_WORKFLOW.md', 'GITHUB_PAGES.md',
        'requirements-local.txt', 'export_run.py', 'run_case.py', '.gitignore'))
    with zipfile.ZipFile(output / 'legalgym-source.zip', 'w', zipfile.ZIP_DEFLATED) as archive:
        for path in sorted(files):
            archive.write(path, Path('law-agent-showcase') / path.relative_to(ROOT))
    for name in ('legalgym-pages.zip', 'legalgym-source.zip'):
        print(output / name)


if __name__ == '__main__':
    main()
