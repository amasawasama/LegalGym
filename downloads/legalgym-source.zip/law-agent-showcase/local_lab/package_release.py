"""Create source, quickstart and static archives without recursive download ZIPs."""
from pathlib import Path
import shutil
import sys
import zipfile

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
from local_lab.package_launcher import main as package_launcher
from local_lab.package_reference import package_reference
DENIED = {'.git', '.run', '.venv', '.local-runtime', '__pycache__', '.DS_Store', 'runs', '.env'}


def public_files(folder):
    for path in sorted(folder.rglob('*')):
        if path.is_file() and not any(part in DENIED for part in path.relative_to(ROOT).parts):
            yield path


def main():
    package_reference()
    output = ROOT / '.run/distribution'
    output.mkdir(parents=True, exist_ok=True)
    files = []
    for directory in ('site', 'case', 'local_lab', 'legalgym-agent-starter', '.github', 'launcher'):
        files.extend(p for p in public_files(ROOT / directory)
                     if p.relative_to(ROOT).parts[:2] != ('site', 'downloads'))
    files.extend(ROOT / name for name in ('README.md', 'LOCAL_WORKFLOW.md', 'GITHUB_PAGES.md',
        'requirements-local.txt', 'export_run.py', 'run_case.py', '.gitignore'))
    with zipfile.ZipFile(output / 'legalgym-source.zip', 'w', zipfile.ZIP_DEFLATED) as archive:
        for path in sorted(files):
            archive.write(path, Path('law-agent-showcase') / path.relative_to(ROOT))
    package_launcher()
    downloads = ROOT / 'site/downloads'
    downloads.mkdir(exist_ok=True)
    for name in ('legalgym-source.zip', 'legalgym-quickstart.zip'):
        shutil.copyfile(output / name, downloads / name)
    with zipfile.ZipFile(output / 'legalgym-pages.zip', 'w', zipfile.ZIP_DEFLATED) as archive:
        for path in public_files(ROOT / 'site'):
            archive.write(path, path.relative_to(ROOT / 'site'))
    for name in ('legalgym-pages.zip', 'legalgym-source.zip'):
        print(output / name)


if __name__ == '__main__':
    main()
