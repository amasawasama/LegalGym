"""Split the public portable reference into small replay data and lazy assets."""
import base64
import json
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parent.parent


def package_reference():
    lab = ROOT / 'site/lab'
    packet = json.loads((lab / 'examples/c06-external-starter.legalgym.json').read_text(encoding='utf-8'))
    folder = lab / 'examples/c06-reference'
    (folder / 'assets').mkdir(parents=True, exist_ok=True)
    assets = {}
    filenames = set()
    for key, value in packet['assets'].items():
        filename = Path(key).name
        if filename in filenames or '/' not in key:
            raise ValueError('Unexpected reference asset path')
        filenames.add(filename)
        (folder / 'assets' / filename).write_bytes(base64.b64decode(value.split(',', 1)[1], validate=True))
        assets[key] = 'assets/' + filename
    packet['assets'] = assets
    (folder / 'replay.json').write_text(json.dumps(packet, ensure_ascii=False, separators=(',', ':')), encoding='utf-8')
    index = {'run': packet['run'], 'packetPath': 'examples/c06-reference/replay.json',
             'packagePath': 'examples/c06-external-starter.legalgym.json'}
    encoded = json.dumps(index, ensure_ascii=False, separators=(',', ':')).replace('</', '<\\/')
    html = lab / 'index.html'
    text = html.read_text(encoding='utf-8')
    text, count = re.subn(r'(<script id="reference-index" type="application/json">).*?(</script>)',
                         lambda m: m[1] + encoded + m[2], text, flags=re.S)
    if count != 1:
        raise ValueError('Expected one inline reference index')
    html.write_text(text, encoding='utf-8')
    return folder


if __name__ == '__main__':
    print(package_reference())
