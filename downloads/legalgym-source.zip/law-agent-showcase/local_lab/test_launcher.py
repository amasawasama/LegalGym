"""Archive boundaries and real local service startup, without making model calls."""
import io
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch
import zipfile

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / 'launcher'))
import bootstrap


class LauncherTests(unittest.TestCase):
    def test_archive_traversal_is_rejected_before_extraction(self):
        stream = io.BytesIO()
        with zipfile.ZipFile(stream, 'w') as archive:
            archive.writestr('law-agent-showcase/ok.txt', 'safe')
            archive.writestr('../escape.txt', 'bad')
        with tempfile.TemporaryDirectory() as folder:
            with self.assertRaises(ValueError):
                bootstrap.unpack(stream.getvalue(), Path(folder) / 'project')
            self.assertFalse((Path(folder) / 'project/law-agent-showcase/ok.txt').exists())
            self.assertFalse((Path(folder) / 'escape.txt').exists())

    def test_symlink_in_archive_is_rejected(self):
        stream = io.BytesIO()
        with zipfile.ZipFile(stream, 'w') as archive:
            item = zipfile.ZipInfo('law-agent-showcase/link')
            item.external_attr = 0o120777 << 16
            archive.writestr(item, '/tmp')
        with tempfile.TemporaryDirectory() as folder:
            with self.assertRaises(ValueError):
                bootstrap.unpack(stream.getvalue(), folder)

    def test_real_services_connect_and_stop_without_exposing_key_to_server(self):
        real_popen = subprocess.Popen
        started = []
        def start(*args, **kwargs):
            if 'local_lab/server.py' in args[0]:
                self.assertNotIn('OPENAI_API_KEY', kwargs['env'])
            child = real_popen(*args, **kwargs)
            started.append(child)
            return child
        env = dict(os.environ, OPENAI_API_KEY='test-only-no-model-call', LEGALGYM_KEY_ENV='OPENAI_API_KEY',
                   LEGALGYM_MODEL='integration-test', PYTHONIOENCODING='utf-8')
        with patch('bootstrap.subprocess.Popen', side_effect=start), patch('bootstrap.webbrowser.open', side_effect=KeyboardInterrupt):
            with self.assertRaises(KeyboardInterrupt):
                bootstrap.start_services(ROOT, Path(sys.executable), env)
        self.assertEqual(len(started), 2)
        self.assertTrue(all(child.poll() is not None for child in started))
