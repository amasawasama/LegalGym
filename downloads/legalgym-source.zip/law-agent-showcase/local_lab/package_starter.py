"""Refresh the static starter download without including credentials or runtime data."""
from pathlib import Path
import zipfile

ROOT = Path(__file__).resolve().parent.parent


def package_starter():
    output = ROOT / "site/lab/legalgym-agent-starter.zip"
    with zipfile.ZipFile(output, "w", zipfile.ZIP_DEFLATED) as archive:
        for path in (ROOT / "legalgym-agent-starter").iterdir():
            if path.is_file() and (path.suffix in {".py", ".md", ".example"} or path.name == ".gitignore"):
                archive.write(path, "legalgym-agent-starter/" + path.name)
    return output


if __name__ == "__main__":
    print(package_starter())
