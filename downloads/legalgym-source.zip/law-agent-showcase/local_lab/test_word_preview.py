"""Preview failures must not remove or replace the exported Word deliverable."""
import hashlib
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
from local_lab.word_preview import render_word_preview


class WordPreviewTests(unittest.TestCase):
    def test_missing_renderer_preserves_word_and_reports_no_preview(self):
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            docx = root / "export.docx"
            docx.write_bytes(b"original-word-bytes")
            with patch("local_lab.word_preview.ROOT", root), patch.dict("os.environ", {
                "LEGALGYM_RENDER_PYTHON": "", "LEGALGYM_RENDER_SCRIPT": ""}):
                metadata = render_word_preview(docx, root)
            self.assertEqual(metadata["previewState"], "unavailable")
            self.assertIsNone(metadata["previewPath"])
            self.assertEqual(metadata["sourceSha256"], hashlib.sha256(b"original-word-bytes").hexdigest())
            self.assertEqual(docx.read_bytes(), b"original-word-bytes")

    def test_invalid_renderer_config_does_not_block_word_download(self):
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            (root / ".local-runtime").mkdir()
            (root / ".local-runtime/doc-preview-config.json").write_text("not JSON")
            docx = root / "export.docx"
            docx.write_bytes(b"word-is-still-here")
            with patch("local_lab.word_preview.ROOT", root):
                metadata = render_word_preview(docx, root)
            self.assertEqual(metadata["previewState"], "unavailable")
            self.assertEqual(docx.read_bytes(), b"word-is-still-here")


if __name__ == "__main__":
    unittest.main()
