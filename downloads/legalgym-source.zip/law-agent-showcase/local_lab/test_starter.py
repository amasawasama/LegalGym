"""Regression checks for text-only pseudo tool calls being mistaken for completion."""
import io
import json
import os
from pathlib import Path
import sys
import unittest
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "legalgym-agent-starter"))
import demo_agent
import starter
import tempfile


class FakeEnvironment:
    def __init__(self):
        self.calls = []

    def list_tools(self):
        return [{"name": "submit", "description": "Submit deliverable", "inputSchema": {"type": "object"}}]

    def check_running(self):
        pass

    def call_tool(self, name, arguments):
        self.calls.append((name, arguments))
        return {"content": [{"type": "text", "text": "Saved"}]}


def response(message):
    return io.BytesIO(json.dumps({"choices": [{"message": message}]}).encode())


class StarterTests(unittest.TestCase):
    def test_connector_saves_portable_replay_to_local_directory(self):
        packet = {"schema": "legalgym.replay.v1", "run": {"id": "test"}, "events": [], "assets": {}}
        class FakeClient:
            def request(self, path):
                return packet
        with tempfile.TemporaryDirectory() as directory:
            output = starter.save_replay_package(FakeClient(), "../test", directory)
            self.assertTrue(output.is_relative_to(Path(directory)))
            self.assertEqual(json.loads(output.read_text())["schema"], "legalgym.replay.v1")

    @patch.dict(os.environ, {"OPENAI_API_KEY": "test-only", "LEGALGYM_KEY_ENV": "OPENAI_API_KEY"})
    def test_pseudo_call_is_not_executed_and_agent_requests_correction(self):
        env = FakeEnvironment()
        messages = []
        responses = [response({"role": "assistant", "content": "<tool_call>submit</tool_call>"}),
                     response({"role": "assistant", "content": None, "tool_calls": [{"id": "test-call",
                        "type": "function", "function": {"name": "submit", "arguments": '{"summary":"actual"}'}}]})]
        with patch("demo_agent.urllib.request.urlopen", side_effect=responses):
            result = demo_agent.run("test task", env, lambda text, **kw: messages.append(text))
        self.assertEqual(env.calls, [("submit", {"summary": "actual"})])
        self.assertTrue(any("尚未收到真实" in message for message in messages))
        self.assertIn("通过 submit", result)

    @patch.dict(os.environ, {"OPENAI_API_KEY": "test-only", "LEGALGYM_KEY_ENV": "OPENAI_API_KEY"})
    def test_claimed_completion_without_submit_does_not_succeed(self):
        env = FakeEnvironment()
        with patch("demo_agent.urllib.request.urlopen", side_effect=lambda *a, **kw:
                   response({"role": "assistant", "content": "I am done"})):
            with self.assertRaisesRegex(RuntimeError, "16 步"):
                demo_agent.run("test task", env, lambda *a, **kw: None)
        self.assertEqual(env.calls, [])


if __name__ == "__main__":
    unittest.main()
