"""Tests of isolation, evidence checks, authentication and the local HTTP boundary."""
import http.server
import io
import json
from pathlib import Path
import tempfile
import threading
import unittest
import urllib.request
import urllib.error
import zipfile
from local_lab.server import Hub, Handler


class HubTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.hub = Hub("http://127.0.0.1:9999", self.temp.name)

    def tearDown(self):
        self.temp.cleanup()

    def new_run(self, name):
        registered = self.hub.register({"name": name, "model": "test-model"})
        self.hub.create_run(registered["id"])
        agent = self.hub.authenticate(registered["id"], registered["token"])
        job = self.hub.next_job(agent)
        return registered, self.hub.runs[job["runId"]]

    def test_run_workspaces_and_event_logs_are_independent(self):
        _, first = self.new_run("one")
        _, second = self.new_run("two")
        first_dir, second_dir = self.hub.root / first["id"], self.hub.root / second["id"]
        original = (second_dir / "workspace/contract.json").read_text()
        (first_dir / "workspace/contract.json").write_text('{"test": "only first"}')
        result = self.hub.mcp(first, {"id": 1, "method": "tools/call", "params": {
            "name": "read_contract", "arguments": {}}})
        self.assertIn("only first", result["result"]["content"][0]["text"])
        self.assertEqual((second_dir / "workspace/contract.json").read_text(), original)
        self.assertEqual(second["toolCalls"], 0)
        rows = [json.loads(line) for line in (first_dir / "events.jsonl").read_text().splitlines()]
        self.assertEqual([e["type"] for e in rows][-2:], ["tool_call", "tool_result"])
        self.assertEqual(rows[-1]["source"], "environment")

    def test_submission_with_unopened_evidence_is_rejected_and_recorded(self):
        _, run = self.new_run("evidence")
        submission = {"summary": "test", "edits": [{"clause": "P01", "severity": "重要",
            "replacement": "replacement", "comment": "comment", "evidenceIds": ["QTE-112"]}],
            "client_note": ["note"], "pending": ["pending"]}
        result = self.hub.mcp(run, {"id": 2, "method": "tools/call", "params": {
            "name": "submit", "arguments": submission}})
        self.assertTrue(result["result"]["isError"])
        self.assertFalse((self.hub.root / run["id"] / "workspace/submission.json").exists())
        self.assertEqual(run["toolErrors"], 1)

    def test_delete_refuses_active_run_and_preserves_other_runs(self):
        _, failed = self.new_run("delete")
        _, kept = self.new_run("keep")
        with self.assertRaises(ValueError):
            self.hub.delete_run(failed["id"])
        failed["status"] = "failed"
        self.hub.delete_run(failed["id"])
        self.assertNotIn(failed["id"], self.hub.runs)
        self.assertFalse((self.hub.root / failed["id"]).exists())
        self.assertTrue((self.hub.root / kept["id"] / "manifest.json").exists())
        reopened = Hub("http://127.0.0.1:9999", self.temp.name)
        self.assertNotIn(failed["id"], reopened.runs)

    def test_failure_summary_explains_text_submit_without_showing_long_output(self):
        _, run = self.new_run("failure")
        run["status"] = "failed"
        self.hub.event(run, "export_error", message="No such file: submission.json")
        self.hub.event(run, "run_finished", message="<tool_call>submit" + "x" * 1000)
        summary = self.hub.summary(run)["failureSummary"]
        self.assertIn("普通文本", summary)
        self.assertLess(len(summary), 100)

    def test_invalid_starter_token_is_rejected(self):
        registered, _ = self.new_run("auth")
        with self.assertRaises(PermissionError):
            self.hub.authenticate(registered["id"], "wrong-token")

    def test_restart_marks_unfinished_runs_as_interrupted(self):
        _, run = self.new_run("restart")
        reopened = Hub("http://127.0.0.1:9999", self.temp.name)
        self.assertEqual(reopened.runs[run["id"]]["status"], "interrupted")


class HTTPTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.server = http.server.ThreadingHTTPServer(("127.0.0.1", 0), Handler)
        self.server.hub = Hub("http://127.0.0.1:9999", self.temp.name)
        self.url = f"http://127.0.0.1:{self.server.server_port}"
        threading.Thread(target=self.server.serve_forever, daemon=True).start()

    def tearDown(self):
        self.server.shutdown()
        self.server.server_close()
        self.temp.cleanup()

    def test_cross_origin_creation_is_rejected(self):
        request = urllib.request.Request(self.url + "/api/runs", data=b"{}",
            headers={"Origin": "https://unrelated.example", "Content-Type": "application/json"})
        with self.assertRaises(urllib.error.HTTPError) as result:
            urllib.request.urlopen(request)
        self.assertEqual(result.exception.code, 403)

    def test_state_hides_token_and_starter_zip_contains_no_secrets(self):
        registered = self.server.hub.register({"name": "test"})
        with urllib.request.urlopen(self.url + "/api/state") as response:
            text = response.read().decode()
        self.assertNotIn(registered["token"], text)
        with urllib.request.urlopen(self.url + "/api/starter.zip") as response:
            archive = zipfile.ZipFile(io.BytesIO(response.read()))
        names = archive.namelist()
        self.assertIn("legalgym-agent-starter/starter.py", names)
        self.assertNotIn("legalgym-agent-starter/.env", names)
        self.assertFalse(any("api.env" in name for name in names))


if __name__ == "__main__":
    unittest.main()
