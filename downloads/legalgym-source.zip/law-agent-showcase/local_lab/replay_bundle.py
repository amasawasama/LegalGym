"""Portable, declarative replay data. No HTML, JavaScript or credentials are exported."""
import base64
import json
import uuid
from pathlib import Path

SCHEMA = "legalgym.replay.v1"
MAX_PACKAGE_BYTES = 64 * 1024 * 1024


def read_json(path, default=None):
    return json.loads(path.read_text(encoding="utf-8")) if path.is_file() else default


def build_replay(run_dir, *, inline=False):
    run_dir = Path(run_dir).resolve()
    run = read_json(run_dir / "manifest.json")
    events_file = run_dir / "events.jsonl"
    events = [json.loads(line) for line in events_file.read_text(encoding="utf-8").splitlines() if line.strip()]
    assets = {}
    total_bytes = 0
    base = f"/api/runs/{run['id']}"

    def add(key, root, relative, mime, url):
        nonlocal total_bytes
        file = (root / relative).resolve()
        if not file.is_relative_to(root.resolve()) or not file.is_file():
            return
        if inline:
            content = file.read_bytes()
            total_bytes += len(content)
            if total_bytes > MAX_PACKAGE_BYTES * 0.7:
                raise ValueError("Replay package exceeds the local 64 MB limit")
            assets[key] = "data:" + mime + ";base64," + base64.b64encode(content).decode("ascii")
        else:
            assets[key] = url

    for event in events:
        if event.get("type") == "screenshot":
            filename = event.get("screenshot", "")
            if filename.startswith("step-") and filename.endswith(".png"):
                add("screenshots/" + filename, run_dir / "workspace/trace", filename,
                    "image/png", base + "/screenshots/" + filename)
    document = run.get("document") or {}
    pages = document.get("previewPages") or ([document["previewPath"]] if document.get("previewPath") else [])
    for path in pages:
        add(path, run_dir / "public/replay", path, "image/png", base + "/replay/" + path)
    word_path = document.get("wordPath", "assets/c06-contract-redline.docx")
    add(word_path, run_dir / "public/replay", word_path,
        "application/vnd.openxmlformats-officedocument.wordprocessingml.document", base + "/replay/" + word_path)
    # Keep server-local paths, auth and provider configuration out of the package.
    public_run = {k: run[k] for k in ["id", "agentName", "agentVersion", "model", "case", "caseVersion", "status",
        "createdAt", "startedAt", "finishedAt", "eventCount", "toolCalls", "toolErrors", "screenshots", "document", "failureSummary"] if k in run}
    public_run["score"] = None
    return {"schema": SCHEMA, "run": public_run, "events": events, "assets": assets,
            "task": (run_dir / "workspace/TASK.md").read_text(encoding="utf-8"),
            "contract": read_json(run_dir / "workspace/contract.json"),
            "submission": read_json(run_dir / "workspace/submission.json"),
            "notice": "Development replay record; not an independently verified benchmark score."}


def write_replay_package(run_dir):
    packet = build_replay(run_dir, inline=True)
    content = json.dumps(packet, ensure_ascii=False).encode("utf-8")
    if len(content) > MAX_PACKAGE_BYTES:
        raise ValueError("Replay package exceeds 64 MB")
    output = Path(run_dir) / "portable-replay.legalgym.json"
    temp = output.with_name(".portable-replay-" + uuid.uuid4().hex + ".tmp")
    temp.write_bytes(content)
    temp.replace(output)
    return output
