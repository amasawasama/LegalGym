"""Ensure the lightweight reference is the same real run as the portable record."""
import base64
import json
from pathlib import Path
import re
import unittest

ROOT = Path(__file__).resolve().parent.parent
LAB = ROOT / 'site/lab'


class ReferenceExampleTests(unittest.TestCase):
    def test_trace_and_deliverable_bytes_are_preserved(self):
        portable = json.loads((LAB / 'examples/c06-external-starter.legalgym.json').read_text())
        folder = LAB / 'examples/c06-reference'
        lightweight = json.loads((folder / 'replay.json').read_text())
        for key in portable.keys() - {'assets'}:
            self.assertEqual(portable[key], lightweight[key], key)
        for key, data in portable['assets'].items():
            path = (folder / lightweight['assets'][key]).resolve()
            self.assertTrue(path.is_relative_to(folder.resolve()))
            self.assertEqual(base64.b64decode(data.split(',', 1)[1]), path.read_bytes(), key)

    def test_inline_index_does_not_depend_on_the_big_download(self):
        html = (LAB / 'index.html').read_text()
        match = re.search(r'<script id="reference-index" type="application/json">(.*?)</script>', html, re.S)
        index = json.loads(match[1])
        packet = json.loads((LAB / index['packetPath']).read_text())
        self.assertEqual(index['run'], packet['run'])
        self.assertEqual(index['run']['status'], 'completed')
        self.assertLess(len(match[1].encode()), 3000)
        self.assertLess((LAB / index['packetPath']).stat().st_size, 50000)
        self.assertTrue((LAB / index['packagePath']).is_file())
