"""Bundle the user-invoked setup scripts, pinning the matching source archive."""
import hashlib
import json
from pathlib import Path
import zipfile

ROOT = Path(__file__).resolve().parent.parent


def main():
    source = ROOT / '.run/distribution/legalgym-source.zip'
    output = ROOT / '.run/distribution/legalgym-quickstart.zip'
    manifest = {'sourceSha256': hashlib.sha256(source.read_bytes()).hexdigest()}
    with zipfile.ZipFile(output, 'w', zipfile.ZIP_DEFLATED) as archive:
        for path in sorted((ROOT / 'launcher').iterdir()):
            if path.is_file() and path.suffix in {'.py', '.md', '.command', '.cmd', '.ps1'}:
                archive.write(path, 'legalgym-quickstart/' + path.name)
        archive.writestr('legalgym-quickstart/release.json', json.dumps(manifest))
    print(output)


if __name__ == '__main__':
    main()
