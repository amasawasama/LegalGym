$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot
$env:LEGALGYM_HOME = Join-Path $env:LOCALAPPDATA 'LegalGym'
$env:UV_INSTALL_DIR = Join-Path $env:LEGALGYM_HOME 'bin'
$env:UV_NO_MODIFY_PATH = '1'
$env:UV_UNMANAGED_INSTALL = $env:UV_INSTALL_DIR
$env:UV_CACHE_DIR = Join-Path $env:LEGALGYM_HOME 'cache'
$env:UV_PYTHON_INSTALL_DIR = Join-Path $env:LEGALGYM_HOME 'python'
$env:PYTHONUTF8 = '1'
try {
    New-Item -ItemType Directory -Force -Path $env:UV_INSTALL_DIR | Out-Null
    $uv = Join-Path $env:UV_INSTALL_DIR 'uv.exe'
    if (-not (Test-Path $uv)) {
        Write-Host 'Downloading official uv installer to prepare Python...'
        [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
        $installer = Join-Path $env:LEGALGYM_HOME 'uv-install.ps1'
        Invoke-WebRequest 'https://astral.sh/uv/0.13.9/install.ps1' -OutFile $installer -UseBasicParsing
        & $installer
    }
    & $uv run --no-project --python 3.12 bootstrap.py $uv
    if ($LASTEXITCODE -ne 0) { throw 'LegalGym setup or runtime exited with an error.' }
} catch {
    Write-Host $_ -ForegroundColor Red
    Read-Host 'Press Enter to close'
    exit 1
}
