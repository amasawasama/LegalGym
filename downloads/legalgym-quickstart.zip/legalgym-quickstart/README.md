# LegalGym 自动配置启动包（预览版）

无需事先安装 Python 或 Git。下载 ZIP 并解压，Mac 运行 Start-Mac.command，Windows 运行 Start-Windows.cmd。系统可能要求确认运行下载的脚本；本包不是签名桌面安装程序，浏览器不会自动替你执行。受管电脑可能限制脚本运行。

启动器通过 uv 官方安装器准备 uv 和 Python 3.12，安装项目依赖与 Playwright Chromium，启动本机后端和示例 agent，然后自动打开浏览器。首次需要联网下载较大的浏览器组件；网络需能访问 Astral、GitHub、PyPI 和 Playwright 下载服务。安装在用户目录，不修改系统 Python 或 shell 配置。uv 安装方式见 https://docs.astral.sh/uv/getting-started/installation/ 。

输入自己的兼容模型 API 地址、模型名及密钥；密钥只保留在当前进程，不保存到文件。请保持终端窗口打开，在网页点击“开始运行”后才会调用模型并可能产生费用。示例 agent 可按 Agent Starter 指南替换为自己的 agent。

Mac 安装位置：~/Library/Application Support/LegalGym；Windows：%LOCALAPPDATA%\LegalGym。日志和运行结果在其中 projects/<版本>/law-agent-showcase/ 下。按 Ctrl+C 停止两个服务；下次运行同一个脚本可复用依赖。关闭终端后运行页将不可用，导出的 .legalgym.json 仍可在网站回放。

新运行可导出 Word；自动生成 Word 全部页面预览仍需另配文档渲染器，本包不自动安装 LibreOffice/Codex 文档运行时。网站参考 replay 自带全部页面，始终可以查看。

Mac 尚未在全新系统验证完整安装；Windows 尚未进行实机验证。若受系统限制无法运行，请使用源码中的手动安装说明。无需安装的真实新任务运行仍需要项目部署云端后端，目前未提供。
