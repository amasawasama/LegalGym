"""User-invoked local setup. No model request is made until Start is clicked."""
import getpass
import hashlib
import io
import json
import os
from pathlib import Path
import socket
import ssl
import subprocess
import sys
import time
import urllib.request
import webbrowser
import zipfile

SOURCE_URL = 'https://amasawasama.github.io/LegalGym/downloads/legalgym-source.zip'


def unpack(content, destination):
    destination = Path(destination).resolve()
    with zipfile.ZipFile(io.BytesIO(content)) as archive:
        for item in archive.infolist():
            target = (destination / item.filename).resolve()
            if not target.is_relative_to(destination) or ((item.external_attr >> 16) & 0o170000) == 0o120000:
                raise ValueError('Unexpected archive path')
            if item.file_size > 64 * 1024 * 1024:
                raise ValueError('Unexpected archive size')
        archive.extractall(destination)


def wait_for_server(url, process, timeout=25):
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        if process.poll() is not None:
            raise RuntimeError('Local server exited; inspect server.log.')
        try:
            with urllib.request.urlopen(url + '/api/state', timeout=1) as response:
                if 'runs' in json.load(response):
                    return
        except (OSError, ValueError):
            time.sleep(.25)
    raise RuntimeError('Local server did not become ready; inspect server.log.')


def start_services(project, python, env):
    processes = []
    logs = project / '.local-runtime/launcher-logs'
    logs.mkdir(parents=True, exist_ok=True)
    streams = []
    try:
        with socket.socket() as probe:
            probe.bind(('127.0.0.1', 0))
            port = probe.getsockname()[1]
        url = f'http://127.0.0.1:{port}'
        # The task server never receives the model key, only the starter does.
        server_env = {k: v for k, v in env.items() if k not in {'OPENAI_API_KEY', 'DEEPSEEK_API_KEY', 'DEPLOY_API_KEY', env.get('LEGALGYM_KEY_ENV', 'OPENAI_API_KEY')}}
        server_log = (logs / 'server.log').open('w', encoding='utf-8')
        streams.append(server_log)
        server = subprocess.Popen([str(python), '-u', 'local_lab/server.py', '--port', str(port)],
            cwd=project, env=server_env, stdout=server_log, stderr=subprocess.STDOUT)
        processes.append(server)
        wait_for_server(url, server)
        starter_log = (logs / 'starter.log').open('w', encoding='utf-8')
        streams.append(starter_log)
        agent = subprocess.Popen([str(python), '-u', 'legalgym-agent-starter/starter.py',
            '--server', url, '--name', 'My First LegalGym Agent'], cwd=project, env=env,
            stdout=starter_log, stderr=subprocess.STDOUT)
        processes.append(agent)
        # Wait for registration, not merely for the child process to exist.
        for _ in range(40):
            if agent.poll() is not None:
                raise RuntimeError('Starter exited; inspect starter.log.')
            with urllib.request.urlopen(url + '/api/state', timeout=2) as response:
                if any(a.get('online') for a in json.load(response)['agents']):
                    break
            time.sleep(.25)
        else:
            raise RuntimeError('Starter did not connect; inspect starter.log.')
        print('\n准备完成！浏览器打开后，选择 Agent 并点击“开始运行”。', flush=True)
        print('运行地址：' + url + '/lab/', flush=True)
        print('日志目录：' + str(logs), flush=True)
        print('请保持此窗口打开。按 Ctrl+C 停止服务；模型请求可能产生费用。', flush=True)
        webbrowser.open(url + '/lab/')
        while True:
            if any(process.poll() is not None for process in processes):
                raise RuntimeError('A local service exited; inspect the log directory above.')
            time.sleep(1)
    finally:
        for process in reversed(processes):
            if process.poll() is None:
                process.terminate()
        for process in reversed(processes):
            try:
                process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                process.kill()
                process.wait()
        for stream in streams:
            stream.close()


def main():
    uv = Path(sys.argv[1]).resolve()
    root = Path(os.environ['LEGALGYM_HOME'])
    print('LegalGym 自动配置启动器（预览版）\n首次联网下载 Python、浏览器和项目依赖；不需要预先安装 Python。')
    print('模型密钥只用于本机 starter，不保存到文件。按回车使用默认模型服务，也可填写自己的兼容接口。')
    base = input('API Base URL [https://api-cdn.deploy.com/api/v1]: ').strip() or 'https://api-cdn.deploy.com/api/v1'
    if not base.startswith('https://'):
        raise ValueError('模型接口请使用 HTTPS 地址。')
    model = input('Model [zai-org/glm-5.3-flash]: ').strip() or 'zai-org/glm-5.3-flash'
    key = getpass.getpass('你的模型 API Key（输入不显示）: ').strip()
    if not key:
        raise ValueError('需要自己的模型 API Key 才能发起新任务。无需密钥查看示例，请访问网站。')
    context = ssl.create_default_context()
    if Path('/etc/ssl/cert.pem').is_file():
        context.load_verify_locations('/etc/ssl/cert.pem')
    print('下载项目…', flush=True)
    expected = json.loads(Path(__file__).with_name('release.json').read_text())['sourceSha256']
    with urllib.request.urlopen(SOURCE_URL + '?v=' + expected[:12], context=context, timeout=90) as response:
        content = response.read(64 * 1024 * 1024 + 1)
    if len(content) > 64 * 1024 * 1024:
        raise ValueError('Source package is too large')
    digest = hashlib.sha256(content).hexdigest()
    if digest != expected:
        raise ValueError('项目版本已更新或下载不完整，请从网站重新下载最新启动包。')
    destination = root / 'projects' / digest[:12]
    project = destination / 'law-agent-showcase'
    if not (project / 'local_lab/server.py').is_file():
        unpack(content, destination)
    python = project / ('.venv/Scripts/python.exe' if os.name == 'nt' else '.venv/bin/python')
    if not python.is_file():
        subprocess.run([str(uv), 'venv', '--python', '3.12', str(project / '.venv')], check=True)
    subprocess.run([str(uv), 'pip', 'install', '--python', str(python), '-r', str(project / 'requirements-local.txt')], check=True)
    subprocess.run([str(python), '-m', 'playwright', 'install', 'chromium'], check=True)
    env = dict(os.environ, OPENAI_API_KEY=key, LEGALGYM_KEY_ENV='OPENAI_API_KEY', LEGALGYM_MODEL=model,
        LEGALGYM_MODEL_BASE_URL=base, PYTHONIOENCODING='utf-8', PYTHONUTF8='1')
    start_services(project, python, env)


if __name__ == '__main__':
    try:
        main()
    except KeyboardInterrupt:
        print('\n已停止本次启动器。')
    except Exception as error:
        print('\n启动未完成：' + str(error))
        input('按回车退出。')
        sys.exit(1)
