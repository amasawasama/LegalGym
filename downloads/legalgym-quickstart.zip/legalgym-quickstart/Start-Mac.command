#!/bin/bash
set -eu
cd "$(dirname "$0")"
export LEGALGYM_HOME="$HOME/Library/Application Support/LegalGym"
export UV_INSTALL_DIR="$LEGALGYM_HOME/bin"
export UV_NO_MODIFY_PATH=1
export UV_CACHE_DIR="$LEGALGYM_HOME/cache"
export UV_PYTHON_INSTALL_DIR="$LEGALGYM_HOME/python"
mkdir -p "$UV_INSTALL_DIR"
trap 'echo "启动器已退出；如遇错误请保留上方提示。"; read -r -p "按回车关闭。" ignored' EXIT
if [ ! -x "$UV_INSTALL_DIR/uv" ]; then
  echo "正在下载官方 uv 安装器，用于自动准备 Python…"
  curl --fail --location --show-error https://astral.sh/uv/0.13.9/install.sh -o "$LEGALGYM_HOME/uv-install.sh"
  sh "$LEGALGYM_HOME/uv-install.sh"
fi
"$UV_INSTALL_DIR/uv" run --no-project --python 3.12 bootstrap.py "$UV_INSTALL_DIR/uv"
